# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import auth,request,session
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.rrd_graph import get_performance_graph

from user_request_model import get_my_requests
from common_request_model import get_segregated_requests

@auth.requires_login()
@handle_exception
def list_my_requests():
    my_requests = get_my_requests()
    requests = get_segregated_requests(my_requests)

    return dict(install_requests = requests[0], 
                clone_requests = requests[1], 
                disk_requests = requests[2], 
                edit_requests= requests[3])

