# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import auth,request,session
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.rrd_graph import get_performance_graph
from applications.baadal.models.common_vm_model import add_vm_task_to_queue
from applications.baadal.models.user_vm_model import update_snapshot_flag, check_snapshot_limit
from applications.baadal.models.user_request_model import is_request_in_queue


@check_vm_owner
@handle_exception       
def snapshot():
    vm_id = int(request.args[0])
    if is_request_in_queue(vm_id, TASK_TYPE_SNAPSHOT_VM):
        session.flash = "Snapshot request already in queue."
    elif check_snapshot_limit(vm_id):
        add_vm_task_to_queue(vm_id, TASK_TYPE_SNAPSHOT_VM, {'snapshot_type': SNAPSHOT_USER})
        session.flash = "Your request to snapshot VM has been queued"
    else:
        session.flash = "Snapshot Limit Reached. Delete Previous Snapshots to take new snapshot."
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))

@check_vm_owner
@handle_exception
def delete_snapshot():
    vm_id = int(request.args[0])
    snapshot_id = int(request.args[1])
    if is_request_in_queue(vm_id, TASK_TYPE_DELETE_SNAPSHOT, snapshot_id=snapshot_id):
        session.flash = "Delete Snapshot request already in queue."
    else:
        add_vm_task_to_queue(vm_id, TASK_TYPE_DELETE_SNAPSHOT, {'snapshot_id':snapshot_id})
        session.flash = "Your delete snapshot request has been queued"
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))

@check_vm_owner
@handle_exception
def revert_to_snapshot():
    vm_id = int(request.args[0])
    snapshot_id = int(request.args[1])
    if is_request_in_queue(vm_id, TASK_TYPE_DELETE_SNAPSHOT, snapshot_id=snapshot_id):
        session.flash = "Delete Snapshot request in queue. Revert operation aborted."
    elif is_request_in_queue(vm_id, TASK_TYPE_REVERT_TO_SNAPSHOT, snapshot_id=snapshot_id):
        session.flash = "Revert to Snapshot request already in queue."
    else:
        add_vm_task_to_queue(vm_id, TASK_TYPE_REVERT_TO_SNAPSHOT, {'snapshot_id':snapshot_id})
        session.flash = "Your revert to snapshot request has been queued"
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))


@check_vm_owner
@handle_exception       
def configure_snapshot():

    vm_id = int(request.args[0])
    flag = request.vars['snapshot_flag']
    update_snapshot_flag(vm_id, flag)

