# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import auth,request,session
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.rrd_graph import get_performance_graph

from applications.baadal.models.user_vm_model import get_request_vm_form, get_my_hosted_vm
from applications.baadal.models.mail_handler import send_email_to_requester
from applications.baadal.models.common_vm_model import is_vm_user, add_vm_task_to_queue
from applications.baadal.models.user_mail_model import send_remind_faculty_email

from applications.baadal.models.user_request_model import is_request_in_queue

@auth.requires_login()
@handle_exception
def request_vm():
    form = get_request_vm_form()
    
    # After validation, read selected configuration and set RAM, CPU and HDD accordingly
    if form.accepts(request.vars, session, onvalidation=request_vm_validation):
        
        send_email_to_requester(form.vars.vm_name)
        if is_vm_user():
            send_remind_faculty_email(form.vars.id)

        logger.debug('VM requested successfully')
        redirect(URL(c='default', f='index'))
    return dict(form=form)


@auth.requires_login()
@handle_exception
def list_my_vm():
    hosted_vm = get_my_hosted_vm()        
    return dict(hosted_vm = hosted_vm)


def handle_vm_operation(vm_id, task_type):

    if is_request_in_queue(vm_id, TASK_TYPE_DELETE_VM):
        session.flash = "Delete request is in queue. No operation can be performed"
    elif is_request_in_queue(vm_id, task_type):
        session.flash = "%s request already in queue." %task_type
    else:
        add_vm_task_to_queue(vm_id,task_type)
        session.flash = '%s request added to queue.' %task_type
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))

@check_vm_owner
@handle_exception
def start_vm():
    handle_vm_operation(request.args[0], TASK_TYPE_START_VM)

@check_vm_owner
@handle_exception
def stop_vm():
    handle_vm_operation(request.args[0], TASK_TYPE_STOP_VM)

@check_vm_owner
@handle_exception
def resume_vm():
    handle_vm_operation(request.args[0], TASK_TYPE_RESUME_VM)

@check_vm_owner
@handle_exception
def suspend_vm():
    handle_vm_operation(request.args[0], TASK_TYPE_SUSPEND_VM)

@check_vm_owner
@handle_exception
def destroy_vm():
    handle_vm_operation(request.args[0], TASK_TYPE_DESTROY_VM)

@check_vm_owner
@handle_exception
def delete_vm():
    handle_vm_operation(request.args[0], TASK_TYPE_DELETE_VM)


@check_vm_owner
@handle_exception       
def show_vm_performance():
    vm_id = int(request.args[0])
    vm_info = get_vm_info(vm_id)    
    return dict(vm_id = vm_id, vm_identity = vm_info.vm_data.vm_identity)

@check_vm_owner
@handle_exception       
def clone_vm():

    vm_id = request.args[0]
    form = get_clone_vm_form(vm_id)
    if form.accepts(request.vars,session):
        session.flash = "Your request has been sent for approval."
        redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))
    elif form.errors:
        session.flash = "Error in form."

    return dict(form=form)

@check_vm_owner
@handle_exception       
def edit_vm_config():

    vm_id = request.args[0]
    form = get_edit_vm_config_form(vm_id)

    if form.accepts(request.vars, session, onvalidation=edit_vm_config_validation, hideerror=True):
        session.flash = "Your request has been queued!!!"
        redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))

    elif form.errors:
        session.flash = "Error in form!!!"

    return dict(form=form)

@check_vm_owner
@handle_exception       
def vm_history():

    vm_id = request.args[0]
    vm_history = get_vm_history(vm_id)        
    return dict(vm_id = vm_id, vm_history = vm_history)

