# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import auth,request,session
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from log_handler import logger
from rrd_graph import get_performance_graph

from applications.baadal.models.user_model import get_user_info
from applications.baadal.models.user_vm_model import get_vm_config, get_vm_user_list
from applications.baadal.models.common_vm_model import is_vm_user, get_vm_operations, get_vm_snapshots
from applications.baadal.models.common_model import is_moderator
from applications.baadal.models.user_mail_model import get_mail_admin_form
from applications.baadal.models.mail_handler import send_email_to_admin
from applications.baadal.models.user_model import grant_vnc_access


@auth.requires_login()
@handle_exception
def verify_faculty():

    username = request.vars['keywords']
    faculty_info = get_user_info(username, [FACULTY])
    if faculty_info != None:
        return faculty_info[1]

@auth.requires_login()
@handle_exception
def add_collaborator():

    username = request.vars['keywords']
    user_info = get_user_info(username)
    if user_info != None:
        return user_info[1]


@check_vm_owner
@handle_exception
def settings():

    vm_id=request.args[0]
    vm_users = None
    vm_info = get_vm_config(vm_id)
    if not vm_info:
        redirect(URL(f='list_my_vm'))
    if not is_vm_user():
        vm_users = get_vm_user_list(vm_id)
    
    vm_operations = get_vm_operations(vm_id)
    vm_snapshots = get_vm_snapshots(vm_id)
    
    return dict(vminfo = vm_info , vmoperations = vm_operations, vmsnapshots = vm_snapshots, vmusers = vm_users)     


@auth.requires_login()
@handle_exception       
def get_updated_graph():

        logger.debug(request.vars['graphType'])
        logger.debug(request.vars['vmIdentity'])
        logger.debug(request.vars['graphPeriod'])
        graphRet = get_performance_graph(request.vars['graphType'], request.vars['vmIdentity'], request.vars['graphPeriod'])
        if not isinstance(graphRet, IMG):
            if is_moderator():
                return H3(graphRet)
            else:
                return H3('VMs RRD File Unavailable!!!')
        else:
            return graphRet


@auth.requires_login()
@handle_exception
def mail_admin():
    form = get_mail_admin_form()
    if form.accepts(request.vars, session):
        email_type = form.vars.email_type
        email_subject = form.vars.email_subject
        email_message = form.vars.email_message
        send_email_to_admin(email_subject, email_message, email_type)
        redirect(URL(c='default', f='index'))
    return dict(form = form)


@check_vm_owner
@handle_exception       
def grant_vnc():

    vm_id = request.args[0]
    session.flash = grant_vnc_access(vm_id)
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))

 
