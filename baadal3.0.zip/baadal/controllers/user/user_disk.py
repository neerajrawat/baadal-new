# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import auth,request,session
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.rrd_graph import get_performance_graph
from applications.baadal.models.user_model import get_attach_extra_disk_form


@check_vm_owner
@handle_exception       
def attach_extra_disk():

    vm_id = request.args[0]
    form = get_attach_extra_disk_form(vm_id)
    if form.accepts(request.vars, session):
        session.flash = "Your request has been sent for approval."
        redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))
    elif form.errors:
        session.flash = "Error in form."

    return dict(form=form)
