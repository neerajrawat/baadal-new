# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.sanity_model import check_vm_snapshot_sanity, delete_orphan_snapshot, delete_snapshot_info


@check_moderator
def snapshot_sanity_check():
    vm_id = request.args[0]
    output = check_vm_snapshot_sanity(vm_id)
    return dict(vm_id=output[0], vm_name=output[1], snapshots=output[2])


@check_moderator
def sync_snapshot():
    task = request.vars['action_type']
    vm_id = request.vars['vm_id']
    logger.debug(request.args)
    if task == 'Delete_Orphan':
        vm_name = request.vars['vm_name']
        snapshot_name = request.vars['snapshot_name']
        delete_orphan_snapshot(vm_name, snapshot_name)
    elif task == 'Delete_Snapshot_Info':
        snapshot_id = request.vars['snapshot_id']
        delete_snapshot_info(snapshot_id)
    redirect(URL(r=request,c='admin',f='snapshot_sanity_check', args = vm_id))


