# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.admin_network_model import is_ip_assigned, get_manage_public_ip_pool_form, add_public_ip_range, add_private_ip_range,get_manage_private_ip_pool_form
from applications.baadal.modules.network_helper import validate_ip_range


@check_moderator
@handle_exception
def manage_public_ip_pool():
    req_type = request.args(0)
    if req_type == 'delete' or request.vars['delete_this_record'] == 'on':
        error_message = is_ip_assigned(request.args(2), private=False)
        if error_message != None:
            session.flash = error_message
            redirect(URL(c='admin', f='manage_public_ip_pool'))
        else:
            session.flash = 'Public IP deleted successfully'
    form = get_manage_public_ip_pool_form()
    return dict(form=form)

@check_moderator
@handle_exception
def validate_public_ip_range():
    rangeFrom = request.vars['rangeFrom']
    rangeTo = request.vars['rangeTo']
    
    from helper import validate_ip_range
    if validate_ip_range(rangeFrom, rangeTo):
        failed = add_public_ip_range(rangeFrom, rangeTo)
        return str(failed)
    else:
        return '-1'

@check_moderator
@handle_exception
def validate_private_ip_range():
    rangeFrom = request.vars['rangeFrom']
    rangeTo = request.vars['rangeTo']
    vlan = request.vars['vlan']
    
    from helper import validate_ip_range
    if validate_ip_range(rangeFrom, rangeTo):
        failed = add_private_ip_range(rangeFrom, rangeTo, int(vlan))
        return str(failed)
    else:
        return '-1'

@check_moderator
@handle_exception
def manage_private_ip_pool():
    
    req_type = request.args(0)
    if req_type == 'delete' or request.vars['delete_this_record'] == 'on':
        error_message = is_ip_assigned(request.args(2), is_private=True)
        if error_message != None:
            session.flash = error_message
            redirect(URL(c='admin', f='manage_private_ip_pool'))
        else:
            session.flash = 'Private IP deleted successfully'
            
    form = get_manage_private_ip_pool_form()
    return dict(form=form)






import time
def network_graph():
    form = FORM(  TABLE
        (  
           TR(INPUT(_name='testcase1', _type='checkbox', _value="1"),'All'),
           TR(INPUT(_name='testcase2', _type='checkbox', _value="2"),'Migrate'),
           TR(INPUT(_name='testcase3', _type='checkbox', _value="3"),'Shutdown'),
           
           
           BR(),
           TR(INPUT(_type='submit',_value='submit'))
          )
      )
    return dict(form=form)

