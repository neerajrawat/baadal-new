# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.admin_vm_model import get_all_vm_list, get_vm_groupby_hosts, get_migrate_vm_form, is_vm_running, update_vm_lock,	check_vm_resource, exec_launch_vm_image, get_launch_vm_image_form
from applications.baadal.models.admin_model import get_util_period_form
from applications.baadal.models.admin_host_model import get_host_util_data
from applications.baadal.models.common_vm_model import add_vm_task_to_queue, get_vm_info

from sanity_model import add_orphan_vm, delete_vm_info

@check_moderator
@handle_exception
def list_all_vm():
    vm_list = get_all_vm_list()
    return dict(vmlist = vm_list)


@check_moderator
@handle_exception
def hosts_vms():

    form = get_util_period_form(submit_form=False)
    util_period = VM_UTIL_10_MINS
    form.vars.util_period = util_period

    host_util_data = get_host_util_data(util_period)
    
    hostvmlist = get_vm_groupby_hosts()        
    return dict(hostvmlist = hostvmlist, host_util_data = dumps(host_util_data), util_form=form)


@check_moderator
@handle_exception
def migrate_vm():

    if_redirect = False
    vm_id = request.args[0]
    
    form = get_migrate_vm_form(vm_id)

    if form == None:
        if_redirect = True
        
    elif form.accepts(request.vars,session,keepvalues = True):

        migrate_vm = True

        if form.vars.live_migration == None:
            if is_vm_running(vm_id):
                response.flash = "Your VM is already running. Kindly turn it off and then retry!!!"
                migrate_vm = False

        if migrate_vm:
            params={}
            params['destination_host'] = form.vars.destination_host
            params['live_migration'] = form.vars.live_migration
            add_vm_task_to_queue(vm_id, TASK_TYPE_MIGRATE_VM, params)
            session.flash = 'Your task has been queued. Please check your task list for status.'
            if_redirect = True

    elif form.errors:
        response.flash = 'Error in form'

    if if_redirect :
        redirect(URL(c = 'admin', f = 'hosts_vms'))
    return dict(form=form)
        
    
@check_moderator
@handle_exception
def lockvm():
    vm_id=request.args[0]
    vminfo=get_vm_info(vm_id)
    if(not vminfo.locked):
        add_vm_task_to_queue(vm_id, TASK_TYPE_DESTROY_VM)
        session.flash = "VM will be force Shutoff and locked. Check the task queue."
        update_vm_lock(vm_id,True)
    else:
        update_vm_lock(vm_id,False)
        session.flash = "Lock Released. Start VM yourself."
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))


@check_moderator
def sync_vm():
    task = request.args[0]
    vm_name = request.args[1]
    host_id = request.args[2]
    if task == 'Delete_Orphan':
        delete_orhan_vm(vm_name, host_id)
    elif task == 'Add_Orphan':
        add_orphan_vm(vm_name, host_id)
    elif task == 'Delete_VM_Info':
        delete_vm_info(vm_name)
    redirect(URL(r=request,c='admin',f='sanity_check'))


@check_moderator
@handle_exception
def vm_utilization():

    form = get_util_period_form()
    util_period = VM_UTIL_24_HOURS
    form.vars.util_period = util_period

    if form.accepts(request.vars, session, keepvalues=True):
        util_period = int(form.vars.util_period)
    
    vm_util_data = get_vm_util_data(util_period)
    
    return dict(vm_util_data=vm_util_data, form=form)


@check_moderator
@handle_exception
def verify_vm_resource():

    request_id = request.vars['request_id']
    return check_vm_resource(request_id)


@check_moderator
@handle_exception       
def launch_vm_image():
    form = get_launch_vm_image_form()
    
    if form.accepts(request.vars, session, onvalidation=launch_vm_image_validation):
        
        exec_launch_vm_image(form.vars.id, form.vars.collaborators, form.vars.extra_disk_list)
        
        logger.debug('VM image launched successfully')
        redirect(URL(c='default', f='index'))
    return dict(form=form)
