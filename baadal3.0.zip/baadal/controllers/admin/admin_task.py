# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.common_task_model import get_task_num_form
from applications.baadal.models.admin_task_model import get_task_by_status, update_task_ignore, update_task_retry

@check_moderator
@handle_exception
def task_list():

    form = get_task_num_form()
    task_num = ITEMS_PER_PAGE
    form.vars.task_num = task_num

    if form.accepts(request.vars, session, keepvalues=True):
        task_num = int(form.vars.task_num)
    
    pending = get_task_by_status([TASK_QUEUE_STATUS_PENDING], task_num)
    success = get_task_by_status([TASK_QUEUE_STATUS_SUCCESS], task_num)
    failed = get_task_by_status([TASK_QUEUE_STATUS_FAILED, TASK_QUEUE_STATUS_PARTIAL_SUCCESS], task_num)
    
    return dict(pending=pending, success=success, failed=failed, form=form)

@check_moderator
@handle_exception
def ignore_task():
    task_id=request.args[0]
    update_task_ignore(task_id)
    
    redirect(URL(r=request,c='admin',f='task_list'))

@check_moderator
@handle_exception
def retry_task():
    event_id=request.args[0]
    update_task_retry(event_id)
    
    redirect(URL(r=request,c='admin',f='task_list'))
