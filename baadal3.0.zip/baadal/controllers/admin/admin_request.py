# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.admin_model import get_all_pending_requests
from applications.baadal.models.common_request_model import get_segregated_requests
from applications.baadal.models.admin_vm_model import enqueue_vm_request
from applications.baadal.models.faculty_model import reject_vm_request


@check_moderator
@handle_exception
def list_all_pending_requests():
    pending_requests = get_all_pending_requests()
    requests = get_segregated_requests(pending_requests)

    return dict(install_requests = requests[0], 
                clone_requests   = requests[1], 
                disk_requests    = requests[2], 
                edit_requests    = requests[3])


@check_moderator
@handle_exception
def approve_request():
    request_id=request.args[0] 
    enqueue_vm_request(request_id);
    session.flash = 'Installation request added to queue'
    redirect(URL(c='admin', f='list_all_pending_requests'))

@check_moderator
@handle_exception
def reject_request():
    request_id=request.args[0]
    reject_vm_request(request_id);
    session.flash = 'Request Rejected'
    redirect(URL(c='admin', f='list_all_pending_requests'))

