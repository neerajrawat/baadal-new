# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.admin_host_model import get_host_util_data, get_all_hostsm, get_search_host_form, get_configure_host_form, configure_host_by_mac,\
	get_host_form, update_host_status, delete_host_from_db, get_host_config

from applications.baadal.modules.rrd_graph import get_performance_graph
from applications.baadal.models.common_model import is_moderator


@check_moderator
def get_host_utilization_data():
    util_period = request.vars['keywords']
    host_util_data = get_host_util_data(util_period)
    return dumps(host_util_data)


@check_moderator
@handle_exception
def host_details():
    hosts = get_all_hosts()

    form1=get_search_host_form()
    form2=get_configure_host_form()

    if form1.process(formname='form_ip').accepted:
        session.flash='Check the details'
        redirect(URL(c='admin', f='add_host',args=form1.vars.host_ip))
        
    if form2.process(formname='form_mac').accepted:
        message = configure_host_by_mac(form2.vars.host_mac_addr)
        session.flash=message
        redirect(URL(c='admin', f='host_details'))

    return dict(form1=form1, form2=form2, hosts=hosts)   

@check_moderator
@handle_exception
def add_host():
    if_redirect = False
    host_ip = request.args[0]
    form = get_host_form(host_ip)
    if form.accepts(request.vars,session):
        session.flash='New Host added'
        if_redirect = True
    elif form.errors:
        session.flash='Error in form'
    if if_redirect :
        redirect(URL(c='admin', f='host_details'))
    else :
        return dict(form=form)


@check_moderator
@handle_exception
def maintenance_host():
    logger.debug("INSIDE MAINTENANCE HOST FUNCTION")
    host_id=request.args[0]
    #migration requests to be added to queue
    update_host_status(host_id, HOST_STATUS_MAINTENANCE)
    redirect(URL(c='admin', f='host_details'))
    
@check_moderator
@handle_exception
def boot_up_host():
    logger.debug("INSIDE BOOT UP HOST FUNCTION")
    host_id=request.args[0]
    if not (update_host_status(host_id, HOST_STATUS_UP)):
        session.flash = 'Host not accessible. Please verify'
    redirect(URL(c='admin', f='host_details'))
    
@check_moderator
@handle_exception
def shut_down_host():
    logger.debug("INSIDE SHUTDOWN HOST FUNCTION")
    host_id=request.args[0]
    #shut down to be implemented
    update_host_status(host_id, HOST_STATUS_DOWN)
    redirect(URL(c='admin', f='host_details'))
    
@check_moderator
@handle_exception
def delete_host():
    host_id=request.args[0]
    delete_host_from_db(host_id)
    redirect(URL(c='admin', f='host_details'))


@check_moderator
@handle_exception       
def show_host_performance():

    host_id = request.args(0)
    host_info = get_host_config(host_id)
    host_identity = str(host_info.host_ip).replace('.','_')
    
    return dict(host_id=host_id, host_identity=host_identity)


@check_moderator
@handle_exception       
def get_updated_host_graph():
#     logger.debug("in")
    logger.debug(request.vars['graphType'])
    logger.debug(request.vars['hostIdentity'])
    logger.debug(request.vars['graphPeriod'])
    graphRet = get_performance_graph(request.vars['graphType'], request.vars['hostIdentity'], request.vars['graphPeriod'])
    if not isinstance(graphRet, IMG):
        if is_moderator():
            return H3(graphRet)
        else:
            return H3('VMs RRD File Unavailable!!!')
    else:
        return graphRet
        
@check_moderator
@handle_exception       
def host_config():
    host_id=request.args(0)
    host_info = get_host_config(host_id)
    logger.debug(host_info)
    return dict(host_info=host_info)

