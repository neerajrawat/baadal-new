# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import delete_orhan_vm, HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant
from applications.baadal.models.admin_for_user_model import get_all_unregistered_users, get_users_with_roles, specify_user_roles,\
	get_search_user_form, get_user_form, disable_user
from applications.baadal.models.common_user_model import get_users_with_organisation, get_user_role_types, delete_all_user_roles
from applications.baadal.models.admin_vm_model import add_user_vm_access, delete_user_vm_access
from applications.baadal.models.mail_handler import send_email_on_successful_registration, send_email_on_registration_denied
from applications.baadal.models.user_model import  get_user_info
 

@check_moderator
@handle_exception
def approve_users():
    pending_users = get_all_unregistered_users()
    users = get_users_with_organisation(pending_users)
    types = get_user_role_types()
    return dict(users = users,
                type_options = types)
                
@check_moderator
@handle_exception
def modify_user_role():
    active_users = get_users_with_roles()
    all_roles = get_user_role_types()
    return dict(users = active_users,
                type_options = all_roles)
    
def modify_roles():
    user_id = request.args[0]
    user_roles = request.args[1]
    if user_roles == "empty":
        user_roles = None
    else:
        user_roles = user_roles.split('_')
    user_id = long(user_id)
    delete_all_user_roles(user_id)
    session.flash= specify_user_roles(user_id, user_roles)
    redirect(URL(c='admin',f='modify_user_role'))


@check_moderator
@handle_exception
def user_details():
    vm_id = request.args[0]
    form = get_search_user_form()
    if form.accepts(request.vars, session, onvalidation = validate_user):
        redirect(URL(c ='admin', f = 'add_user_to_vm', args = [form.vars.user_id, vm_id]))
    elif form.errors:
        session.form = 'Invalid user id'

    return dict(form=form)

@check_moderator
@handle_exception
def add_user_to_vm():
    username = request.args[0]
    vm_id = request.args[1]
    form = get_user_form(username, vm_id)

    if form.accepts(request.vars,session):
        
        user_set = set({form.vars.user_id})
    
        if not is_vm_name_unique(user_set, vm_id=vm_id):
            form.errors.vm_name = 'VM name should be unique for the user.'

        add_user_vm_access(vm_id, form.vars.user_id)
        session.flash = "User is added to vm"
        redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))
    elif form.errors:
        session.form = 'Error in form'
    return dict(form = form)

@check_moderator
@handle_exception
def delete_user_vm():
    vm_id=request.args[0]
    user_id=request.args[1]
    delete_user_vm_access(int(vm_id), int(user_id))    			
    session.flash = 'User access for the VM is removed.'
    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))


@check_moderator
@handle_exception
def add_user_with_role():
    user_id = request.args[0]
    user_roles = request.args[1]
    if user_roles == "empty":
        user_roles = None
    else:
        user_roles = user_roles.split('_')
    user_id = long(user_id)
    send_email_on_successful_registration(user_id)
    session.flash= specify_user_roles(user_id, user_roles)
    redirect(URL(c='admin',f='approve_users'))
 

@check_moderator
@handle_exception       
def verify_user():
    username = request.vars['keywords']
    user_info = get_user_info(username)
    if user_info != None:
        return user_info[1]



@check_moderator
@handle_exception   
def remove_user():
    user_id=request.args[0]
    send_email_on_registration_denied(user_id)
    session.flash = disable_user(user_id)
    redirect(URL(c='admin',f='approve_users'))


