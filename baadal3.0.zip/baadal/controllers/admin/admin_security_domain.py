# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant

from applications.baadal.models.admin_security_domain_model import check_delete_security_domain, get_security_domain_form


@check_moderator
@handle_exception
def manage_security_domain():

    req_type = request.args(0)
    if req_type == 'delete' or request.vars['delete_this_record'] == 'on':
        error_message = check_delete_security_domain(request.args(2))
        if error_message != None:
            session.flash = error_message
            redirect(URL(c='admin', f='manage_security_domain'))

    form = get_security_domain_form()
    return dict(form = form)

