# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_vms import delete_orhan_vm
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS
from applications.baadal.modules.rrd_graph import get_performance_graph
from applications.baadal.modules.helper import get_constant
from applications.baadal.models.common_vm_model import add_vm_task_to_queue
from applications.baadal.models.sanity_model import get_host_sanity_form, check_vm_sanity
from applications.baadal.models.user_mail_model import send_remind_orgadmin_email
from applications.baadal.models.admin_model import get_baadal_status_info
from applications.baadal.models.mail_handler import send_shutdown_email_to_all


@check_moderator
@handle_exception
def delete_machine():   
    vm_id=request.args[0]
    add_vm_task_to_queue(vm_id,TASK_TYPE_DELETE_VM)    

    redirect(URL(r = request, c = 'user', f = 'settings', args = vm_id))


@check_moderator
def sanity_check():

    form = get_host_sanity_form()
    host_selected = -1
    form.vars.host_selected = host_selected

    if form.accepts(request.vars, session, keepvalues=True):
        host_selected = int(form.vars.host_selected)
    
    output = check_vm_sanity(host_selected) if host_selected != -1 else []
    
    return dict(sanity_data=output, form=form)
    

@check_moderator
@handle_exception
def remind_orgadmin():
    vm_id=request.args[0]
    send_remind_orgadmin_email(vm_id)
    session.flash = 'Organisation Admin Reminded'
    redirect(URL(c='orgadmin', f='pending_approvals'))


@check_moderator
@handle_exception   
def baadal_status():
    vm_list = get_baadal_status_info()
    baadal_status = get_constant('baadal_status')
    return dict(vm_list=vm_list, baadal_status=baadal_status)


@check_moderator
@handle_exception   
def start_shutdown():
    shutdown_baadal()


@check_moderator
@handle_exception   
def send_shutdown_mail():
    send_shutdown_email_to_all()

    
@check_moderator
@handle_exception   
def start_bootup():
    bootup_baadal()






