# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import request,response,session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from simplejson import dumps
from applications.baadal.modules.maintenance import shutdown_baadal, bootup_baadal
from applications.baadal.modules.host_helper import delete_orhan_vm, HOST_STATUS_UP, HOST_STATUS_DOWN,\
    HOST_STATUS_MAINTENANCE
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_utilization import VM_UTIL_10_MINS, VM_UTIL_24_HOURS, get_performance_graph
from applications.baadal.modules.helper import get_constant
from applications.baadal.models.admin_vm_model import check_vm_extra_disk


@check_moderator
@handle_exception       
def verify_extra_disk():
    vm_image_name = request.vars['vm_image_name']
    disk_name = request.vars['disk_name']
    datastore_id = request.vars['datastore_id']

    disk_info = check_vm_extra_disk(vm_image_name, disk_name, datastore_id)
    return disk_info
    
