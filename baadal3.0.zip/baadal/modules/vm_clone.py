if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from helper import execute_remote_cmd, choose_datastore  # @UnusedWildImport
from nat_mapper import create_mapping, remove_mapping
from vm_network import choose_mac_ip_vncport
from host_helper import host_resources_used, find_new_host
from vm_helper import update_db_after_vm_installation, free_vm_properties
from vm_migration import migrate_clone_to_new_host

#get vm clone properties
def get_clone_properties(vm_details, cloned_vm_details, vm_properties):
    
    datastore = choose_datastore()
    vm_properties['datastore'] = datastore
    logger.debug("Datastore selected is: " + str(datastore))

    vm_properties['security_domain'] = vm_details.security_domain
    vm_properties['public_ip_req'] = False
    # Finds mac address, ip address and vnc port for the cloned vm
    choose_mac_ip_vncport(vm_properties)
    logger.debug("MAC is : " + str(vm_properties['mac_addr']) + " IP is : " + str(vm_properties['private_ip']) + \
                         " VNCPORT is : " + str(vm_properties['vnc_port']))
  
    # Template and host of parent vm
    vm_properties['template'] = current.db(current.db.template.id == vm_details.template_id).select()[0]
    vm_properties['vm_host_details'] = current.db.host[vm_details.host_id]
    
    vm_properties['host'] = vm_properties['vm_host_details'].id
    # Creates a directory for the cloned vm
    logger.debug("Creating directory for cloned vm...")
    cloned_vm_directory_path = datastore.system_mount_point + '/' + get_constant('vms') + '/' + cloned_vm_details.vm_identity
    if not os.path.exists (cloned_vm_directory_path):
        os.makedirs(cloned_vm_directory_path)
        clone_file_parameters = ' --file ' + cloned_vm_directory_path + '/' + cloned_vm_details.vm_identity + '.qcow2'
    else:
        raise Exception("Directory with same name as vmname already exists.")

    # Creates a folder for additional disks of the cloned vm
    vm = current.db(current.db.vm_data.vm_identity == vm_details.vm_identity).select().first()
    disk_details_of_cloning_vm = current.db(current.db.attached_disks.vm_id == vm.id).select(orderby=current.db.attached_disks.attached_disk_name)
    logger.debug(disk_details_of_cloning_vm)
    already_attached_disks = len(disk_details_of_cloning_vm) 
    
    cloned_vm_extra_disks_directory = datastore.system_mount_point + '/' + get_constant('extra_disks_dir') + '/' + \
                                      datastore.ds_name +  '/' + cloned_vm_details.vm_identity
    if already_attached_disks > 0:
        if not os.path.exists (cloned_vm_extra_disks_directory):
            logger.debug("Making Directory")          
            os.makedirs(cloned_vm_extra_disks_directory)
    count = already_attached_disks
    while already_attached_disks > 0:
        
        disk_name = cloned_vm_details.vm_identity + '_disk' + str(count - already_attached_disks + 1) + '.qcow2'
        clone_file_parameters += ' --file ' + cloned_vm_extra_disks_directory + '/' + disk_name
        current.db.attached_disks.insert(vm_id = cloned_vm_details.id, 
                                          datastore_id = datastore.id , 
                                          attached_disk_name = disk_name, 
                                          capacity = disk_details_of_cloning_vm[count - already_attached_disks].capacity)
        #logger.debug(db._lastsql)
        already_attached_disks -= 1

    return (clone_file_parameters)
                
        
# Clones vm
def clone(vmid):
    
    vm_properties = {}
    logger.debug("Inside clone() function")
    cloned_vm_details = current.db.vm_data[vmid]
    vm_details = current.db(current.db.vm_data.id == cloned_vm_details.parent_id).select().first()
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        if domain.info()[0] != VIR_DOMAIN_SHUTOFF:
            raise Exception("VM is not shutoff. Check vm status.")
        connection_object.close()
        clone_file_parameters = get_clone_properties(vm_details, cloned_vm_details, vm_properties)
        logger.debug("cloned vm properties after clone_file_parameters" + str(vm_properties))
        host = vm_properties['vm_host_details']
        logger.debug("host is: " + str(host))
        logger.debug("host details are: " + str(host))
        (used_ram, used_cpu) = host_resources_used(host.id)
        logger.debug("uram: " + str(used_ram) + " used_cpu: " + str(used_cpu) + " host ram: " + str(host.RAM) +" host cpu: " + str(host.CPUs))
        host_ram_after_200_percent_overcommitment = math.floor((host.RAM * 1024) * 2)
        host_cpu_after_200_percent_overcommitment = math.floor(host.CPUs * 2)
        logger.debug("host_ram_after_200_percent_overcommitment in MB " + str(host_ram_after_200_percent_overcommitment))
        logger.debug("host_cpu_after_200_percent_overcommitment " + str(host_cpu_after_200_percent_overcommitment))
        logger.debug("Available RAM on host: %s, Requested RAM: %s" % ((host_ram_after_200_percent_overcommitment - used_ram), vm_details.RAM))
        logger.debug("Available CPUs on host: %s, Requested CPU: %s " % ((host_cpu_after_200_percent_overcommitment - used_cpu), vm_details.vCPU))
        

        if((( host_ram_after_200_percent_overcommitment - used_ram) >= vm_details.RAM) and ((host_cpu_after_200_percent_overcommitment - used_cpu) >= vm_details.vCPU) and (vm_details.vCPU <= host.CPUs)):
            clone_command = "virt-clone --original " + vm_details.vm_identity + " --name " + cloned_vm_details.vm_identity + \
                        clone_file_parameters + " --mac " + vm_properties['mac_addr']
            command_output = execute_remote_cmd(vm_details.host_id.host_ip, 'root', clone_command, None, True)
            logger.debug(command_output)
            logger.debug("Updating db after cloning")
            update_db_after_vm_installation(cloned_vm_details, vm_properties, parent_id = vm_details.id)
            message = "Cloned successfully. "

            try:
                new_host_id_for_cloned_vm = find_new_host(cloned_vm_details.RAM, cloned_vm_details.vCPU)
                if new_host_id_for_cloned_vm != host.id:
                    if migrate_clone_to_new_host(vm_details, cloned_vm_details, new_host_id_for_cloned_vm,vm_properties):
                        message += "Found new host and migrated successfully."
                    else:
                        message += "Found new host but not migrated successfully."
                else:
                    message += "New host selected to migrate cloned vm is same as the host on which it currently resides."
            except:
                message += "Could not find host to migrate cloned vm."
        
            logger.debug("Task Status: SUCCESS Message: %s " % message)
            return (current.TASK_QUEUE_STATUS_SUCCESS, message)

        else:
            raise Exception("Host resources exhausted. Migrate the host vms and then try.")        
    except:
        free_vm_properties(cloned_vm_details, vm_properties)
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

'''
def free_cloned_vm_properties(cloned_vm_details, vm_properties):

    logger.debug("Cloned VM installation fails..Starting to delete directory")

    # Wont work for clone. Check
    cloned_vm_directory_path = vm_properties['datastore'].system_mount_point + '/' + get_constant('vms') + '/' + cloned_vm_details.vm_identity
    if os.path.exists (cloned_vm_directory_path):
        logger.debug("Starting to delete vm directory.")
        shutil.rmtree(cloned_vm_directory_path)
    return
'''

