# -*- coding: utf-8 -*-
###################################################################################
""" vm_utilization.py:  Captures utilization data for virtual machines & hosts;  
and stores the information in a RRD database. 
RRD is a Round Robin Database which is created for pre-defined time interval. 
When new data reaches the starting point, it overwrites existing data. The RRDtool 
database is structured in such a way that it needs data at predefined time intervals. 
Then graphs can be directly generated from the information by specifying the 
Consolidation Function.
For more information on rrdtool visit http://oss.oetiker.ch/rrdtool/

Following utilization data is captured for each Host and VM:
Memory
CPU
Network(read & write)
Disk (read & write)

For virtual machines, CPU, network and disk utilization information is fetched from
the respective domain running on the hypervisor. Memory utilization is fetched from  
host, since VMs run as processes on the host.

"""
import os, re, time, rrdtool, libvirt
from xml.etree import ElementTree
from log_handler import rrd_logger
from gluon import IMG, URL, current
from helper import get_constant, get_context_path, execute_remote_cmd

VM_UTIL_10_MINS = 1
VM_UTIL_24_HOURS = 2
VM_UTIL_ONE_WEEK = 3
VM_UTIL_ONE_MNTH = 4
VM_UTIL_ONE_YEAR = 5

STEP         = 300
TIME_DIFF_MS = 550

def get_rrd_file(identity):

    rrd_file = get_constant("vmfiles_path") + os.sep + get_constant("vm_rrds_dir") + os.sep + identity + ".rrd"
    return rrd_file

""""Generate graph for given RRD file and period"""
def create_graph(rrd_file_name, graph_type, rrd_file_path, graph_period):

    rrd_logger.debug(rrd_file_name+" : "+graph_type+" : "+rrd_file_path+" : "+graph_period)
    #rrd_file = rrd_file_name + '.rrd'       

    #shutil.copyfile(rrd_file_path, rrd_file)
    graph_file = rrd_file_name + "_" + graph_type + ".png"
    graph_file_dir = os.path.join(get_context_path(), 'static' + get_constant('graph_file_dir'))
    graph_file_path = graph_file_dir + os.sep + graph_file

    start_time = None
    consolidation = 'MIN'
    ds = ds1 = ds2 = None
    line = line1 = line2 = None

    
    if graph_period == 'hour':
        start_time = 'now - ' + str(24*60*60)
    elif graph_period == 'day':
        start_time = '-1w'
    elif graph_period == 'month':
        start_time = '-1y'
    elif graph_period == 'week':
        start_time = '-1m'
    elif graph_period == 'year':
        start_time = '-5y'
  
    if ((graph_type == 'ram') or (graph_type == 'cpu')):

        if graph_type == 'ram':
            ds = 'DEF:ram=' + rrd_file_path + ':ram:' + consolidation
            line = 'LINE1:ram#0000FF:Memory'
            graph_type += " (Bytes/Sec)"
            upper_limit = ""
        elif graph_type == 'cpu':
            ds = 'DEF:cpu=' + rrd_file_path + ':cpu:' + consolidation
            line = 'LINE1:cpu#0000FF:CPU'
            graph_type += " (%)"
            upper_limit = "-u 100"
                
        rrdtool.graph(graph_file_path, '--start', start_time, '--end', 'now', '--vertical-label', graph_type, '--watermark', time.asctime(), '-t', ' ' + rrd_file_name, ds, line, "-l 0 --alt-y-grid -L 6" + upper_limit )

    else:

        if graph_type == 'nw':
            ds1 = 'DEF:nwr=' + rrd_file_path + ':tx:' + consolidation
            ds2 = 'DEF:nww=' + rrd_file_path + ':rx:' + consolidation
            line1 = 'LINE1:nwr#0000FF:Transmit'
            line2 = 'LINE1:nww#FF7410:Receive'

        elif graph_type == 'disk':
            ds1 = 'DEF:diskr=' + rrd_file_path + ':dr:' + consolidation
            ds2 = 'DEF:diskw=' + rrd_file_path + ':dw:' + consolidation
            line1 = 'LINE1:diskr#0000FF:DiskRead'
            line2 = 'LINE1:diskw#FF7410:DiskWrite'

        graph_type += " (Bytes/Sec)"

        rrdtool.graph(graph_file_path, '--start', start_time, '--end', 'now', '--vertical-label', graph_type, '--watermark', time.asctime(), '-t', ' ' + rrd_file_name, ds1, ds2, line1, line2, "-l 0 --alt-y-grid -L 6" )

    rrd_logger.debug(graph_file_path)

    if os.path.exists(graph_file_path):
        return True
    else:
        return False
    
""""Fetch graph for given RRD file and period"""
def get_performance_graph(graph_type, vm, graph_period):

    error = None
    img = IMG(_src = URL("static" , "images/no_graph.jpg") , _style = "height:100px")

    try:
        rrd_file = get_rrd_file(vm)
  
        if os.path.exists(rrd_file):
            if create_graph(vm, graph_type, rrd_file, graph_period):   
                img_pos = "images/vm_graphs/" + vm + "_" + graph_type + ".png"
                img = IMG(_src = URL("static", img_pos), _style = "height:100%")
                rrd_logger.info("Graph created successfully")
            else:
                rrd_logger.warn("Unable to create graph from rrd file!!!")
                error = "Unable to create graph from rrd file"
        else:
            rrd_logger.warn("VMs RRD File Unavailable!!!")
            error = "VMs RRD File Unavailable!!!"
    except: 
        rrd_logger.warn("Error occured while creating graph.")
        import sys, traceback
        etype, value, tb = sys.exc_info()
        error = ''.join(traceback.format_exception(etype, value, tb, 10))
        rrd_logger.debug(error)

    finally:
        if error != None:
            return error
        else:
            rrd_logger.info("Returning image.")
            return img


""""Fetch RRD data to display in tabular format"""
def fetch_rrd_data(rrd_file_name, period=VM_UTIL_24_HOURS):
    rrd_file = get_rrd_file(rrd_file_name)

    start_time = 'now-' + str(24*60*60)
    end_time = 'now'
    
    if period == VM_UTIL_10_MINS:
        start_time = 'now-' + str(10*60)
    elif period == VM_UTIL_ONE_WEEK:
        start_time = '-1w'
    elif period == VM_UTIL_ONE_MNTH:
        start_time = '-1m'
    elif period == VM_UTIL_ONE_YEAR:
        start_time = '-1y'
    cpu_data = []
    mem_data = []
    dskr_data = []
    dskw_data = []
    nwr_data = []
    nww_data = []
    if os.path.exists(rrd_file):
        rrd_ret =rrdtool.fetch(rrd_file, 'MIN', '--start', start_time, '--end', end_time)

        fld_info = rrd_ret[1]
        data_info = rrd_ret[2]
        cpu_idx = fld_info.index('cpu')
        mem_idx = fld_info.index('ram')
        dskr_idx = fld_info.index('dr')
        dskw_idx = fld_info.index('dw')
        nwr_idx = fld_info.index('tx')
        nww_idx = fld_info.index('rx')
        
        #Ignore the None values before computing average
        for row in data_info:
            if row[cpu_idx] != None: cpu_data.append(float(row[cpu_idx])) 
            if row[mem_idx] != None: mem_data.append(float(row[mem_idx]))
            if row[dskr_idx] != None: dskr_data.append(float(row[dskr_idx]))
            if row[dskw_idx] != None: dskw_data.append(float(row[dskw_idx]))
            if row[nwr_idx] != None: nwr_data.append(float(row[nwr_idx]))
            if row[nww_idx] != None: nww_data.append(float(row[nww_idx]))
    
    return (sum(mem_data)/float(len(mem_data)) if len(mem_data) > 0 else 0, 
            sum(cpu_data)/float(len(cpu_data)) if len(cpu_data) > 0 else 0, 
            sum(dskr_data)/float(len(dskr_data)) if len(dskr_data) > 0 else 0,
            sum(dskw_data)/float(len(dskw_data)) if len(dskw_data) > 0 else 0,
            sum(nwr_data)/float(len(nwr_data)) if len(nwr_data) > 0 else 0,
            sum(nww_data)/float(len(nww_data)) if len(nww_data) > 0 else 0)
   
"""Create the RRD file"""
def create_rrd(rrd_file):

    ret = rrdtool.create( rrd_file, "--step", str(STEP) ,"--start", str(int(time.time())),
        "DS:cpu:GAUGE:%s:0:U"   % str(TIME_DIFF_MS),
        "DS:ram:GAUGE:%s:0:U"     % str(TIME_DIFF_MS),
        "DS:dr:GAUGE:%s:0:U"    % str(TIME_DIFF_MS),
        "DS:dw:GAUGE:%s:0:U"    % str(TIME_DIFF_MS),
        "DS:tx:GAUGE:%s:0:U"      % str(TIME_DIFF_MS),
        "DS:rx:GAUGE:%s:0:U"      % str(TIME_DIFF_MS),
        "RRA:MIN:0:1:200000",       # Data stored for every five minute
        "RRA:AVERAGE:0.5:12:100",   # Average data stored for every hour (300*12)
        "RRA:AVERAGE:0.5:288:50",   # Average data stored for every day (300*288)
        "RRA:AVERAGE:0.5:8928:24",  # Average data stored for every month (300*8928)
        "RRA:AVERAGE:0.5:107136:10")# Average data stored for every year (300*107136)

    if ret:
        rrd_logger.warn(rrdtool.error())


def update_rrd(host_ip):

        #UPDATE HOST RRD
        rrd_logger.info("Startiing rrd updation for host %s" % (host_ip))
        update_host_rrd(host_ip)
        rrd_logger.info("Ending rrd updation for host %s" % (host_ip))


        #UPDATE RRD for ALL VMs on GIVEN HOST

        rrd_logger.info("Startiing rrd updation for VMs on host %s" % (host_ip))

        hypervisor_conn = None

        try:

            hypervisor_conn = libvirt.openReadOnly("qemu+ssh://root@" + host_ip + "/system")
            rrd_logger.debug(hypervisor_conn.getHostname())

            active_dom_ids  = hypervisor_conn.listDomainsID()
            all_dom_objs    = hypervisor_conn.listAllDomains()

            for dom_obj in all_dom_objs:

                try:

                    rrd_logger.info("Starting rrd updation for vm %s on host %s" % (dom_obj.name(), host_ip))
                    update_vm_rrd(dom_obj, active_dom_ids, host_ip)

                except Exception, e:
                    
                    rrd_logger.debug(e)
                    rrd_logger.debug("Error occured while creating/updating rrd for VM : %s" % dom_obj.name())
  
                finally:

                    rrd_logger.info("Ending rrd updation for vm %s on host %s" % (dom_obj.name(), host_ip))
                
 
        except Exception, e:
        
            rrd_logger.debug(e)

        finally:

            if hypervisor_conn:
                hypervisor_conn.close()


def update_host_rrd(host_ip):

    try:

        rrd_file = get_rrd_file(host_ip.replace(".","_"))
        timestamp_now = time.time()

        if not (os.path.exists(rrd_file)):

            rrd_logger.warn("RRD file (%s) does not exists" % (rrd_file))
            rrd_logger.warn("Creating new RRD file")
            create_rrd(rrd_file)

        else:

            host_stats = get_host_resources_usage(host_ip)
            rrdtool.update(rrd_file, "%s:%s:%s:%s:%s:%s:%s" % (timestamp_now, host_stats['cpu'], host_stats['ram'], host_stats['dr'], host_stats['dw'], host_stats['tx'], host_stats['rx']))

    except Exception, e:

        rrd_logger.debug("Error occured while creating/updating rrd for host: %s" % (host_ip))
        rrd_logger.debug(e)


def update_vm_rrd(dom, active_dom_ids, host_ip):

        dom_name = dom.name()
        rrd_file = get_rrd_file(dom.name())

        if not (os.path.exists(rrd_file)):
            rrd_logger.warn("RRD file (%s) does not exists" % (rrd_file))
            rrd_logger.warn("Creating new RRD file")
            create_rrd(rrd_file)

        else:

            timestamp_now = time.time()

            if dom.ID() in active_dom_ids:

                vm_usage = get_actual_usage(dom, host_ip)
                rrd_logger.debug("Usage Info for VM %s: %s" % (dom_name, vm_usage))
                rrdtool.update(rrd_file, "%s:%s:%s:%s:%s:%s:%s" % (timestamp_now, vm_usage['cpu'], vm_usage['ram'], vm_usage['dr'], vm_usage['dw'], vm_usage['tx'], vm_usage['rx']))
            else:

                rrdtool.update(rrd_file, "%s:0:0:0:0:0:0" % (timestamp_now))
