# -*- coding: utf-8 -*-
###################################################################################

import os, re, random
import paramiko
from gluon.validators import Validator
from gluon import current
from log_handler import logger


def get_context_path():

    ctx_path = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
    return ctx_path

def get_config_file():

    import ConfigParser    
    config = ConfigParser.ConfigParser()
    config.read(os.path.join(get_context_path(), 'static/baadalapp.cfg'));
    return config

config = get_config_file()

def get_datetime():
    import datetime
    return datetime.datetime.now()

# Get value from table 'costants'
def get_constant(constant_name):
    constant = current.db.constants(name = constant_name)['value']
    return constant

# Update value into table 'costants'
def update_constant(constant_name, constant_value):
    current.db(current.db.constants.name == constant_name).update(value = constant_value)
    return 

#Executes command on remote machine using paramiko SSHClient
def execute_remote_cmd(machine_ip, user_name, command, password = None, ret_list = False):

    logger.debug("executing remote command %s on %s with %s:"  %(command, machine_ip, user_name))

    output = None
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(machine_ip, username = user_name, password = password)
        logger.debug("Connected to host %s " % machine_ip)
        stdin,stdout,stderr = ssh.exec_command(command)  # @UnusedVariable
        
        output = stdout.readlines() if ret_list else "".join(stdout.readlines())
        #logger.debug("Output : %s " % output)

        error = "".join(stderr.readlines())
        if (stdout.channel.recv_exit_status()) != 0:
            raise Exception("Exception while executing remote command %s on %s: %s" %(command, machine_ip, error))
    except paramiko.SSHException:
        log_exception()
        raise
    finally:
        if ssh:
            ssh.close()
    
    return output

#Executes command on remote machine using paramiko SSHClient
def execute_remote_bulk_cmd(machine_ip, user_name, command, password=None):

    logger.debug("executing remote command %s on %s:"  %(command, machine_ip))

    output = None
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(machine_ip, username=user_name)
        channel = ssh.invoke_shell()
        stdin = channel.makefile('wb')
        stdout = channel.makefile('rb')
        logger.debug("Connected to host %s " % machine_ip)
        stdin.write(command)

        if (stdout.channel.recv_exit_status()) != 0:
            raise Exception("Exception while executing remote command %s on %s" %(command, machine_ip))
        output = stdout.read()
        stdout.close()
        stdin.close()
    except paramiko.SSHException:
        log_exception()
    finally:
        if ssh:
            ssh.close()
    
    return output

def log_exception(message=None, log_handler=None):
    
    log_handler = logger if log_handler == None else log_handler
    import sys, traceback
    etype, value, tb = sys.exc_info()
    trace = ''.join(traceback.format_exception(etype, value, tb, 10))
    if message:
        trace = message + trace
    log_handler.error(trace)
    return trace


"""Custom validator to check if string is a valid mac address"""
class IS_MAC_ADDRESS(Validator):
    
    regex = re.compile('^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')
    
    def __init__(self, error_message='enter valid MAC address'):
        self.error_message = error_message

    def __call__(self, value):
        if self.regex.match(value):
            return (value, None)
        else:
            return (value, self.error_message)


# Chooses datastore from a list of available datastores
def choose_datastore():

    # datastore_capacity = current.db(current.db.datastore.id >= 0).select(orderby = current.db.datastore.used
    datastores = current.db(current.db.datastore.id >= 0).select()
    datastore_length = len(datastores)
    logger.debug("datastore_lengtn" + str(datastore_length))
    if(datastore_length == 0):
        raise Exception("No datastore found.")
    else:
        count = datastore_length
        available_datastores = {}
        while count != 0:
            available = datastores[datastore_length-count].capacity - datastores[datastore_length-count].used
            available_datastores[datastores[datastore_length-count]] = available
            count = count-1
        z = [(i,available_datastores[i]) for i in available_datastores]
        z.sort(key=lambda x: x[1])
        available_datastores = z
        logger.debug("available d" + str(available_datastores[-1]))
        first_elts = available_datastores[-1]
        first_elts = first_elts[0]

        logger.debug("selected database" + str(first_elts))
        return first_elts
