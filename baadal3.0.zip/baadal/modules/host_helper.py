# -*- coding: utf-8 -*-
###################################################################################
import libvirt,commands  # @UnusedImport
from libvirt import *  # @UnusedWildImport
from helper import *  # @UnusedWildImport
from random import randrange
from host_resource_details import *
from vm_helper import launch_vm_on_host

#Host Status
HOST_STATUS_DOWN = 0
HOST_STATUS_UP = 1
HOST_STATUS_MAINTENANCE = 2

HOST_TYPE_PHYSICAL = "Physical"
HOST_TYPE_VIRTUAL = "Virtual"


get_host_name={"10.0.0.5":"baadal_host_1","10.0.0.6":"baadal_host_2","10.0.0.7":"baadal_host_3","10.0.0.8":"baadal_host_4","10.0.0.9":"baadal_host_5","10.0.0.10":"baadal_host_6","10.0.0.11":"baadal_host_7","10.0.0.12":"baadal_host_8","10.0.0.13":"baadal_host_9"}



#Returns all the host running vms of particular run level
def find_new_host(RAM, vCPU):
    hosts = current.db(current.db.host.status == 1).select()
    hosts = hosts.as_list(True,False) 
    while hosts:
        host = random.choice(hosts)
        logger.debug("Checking host =" + host['host_name'])
        (used_ram, used_cpu) = host_resources_used(host['id'])
        logger.debug("used ram: " + str(used_ram) + " used cpu: " + str(used_cpu) + " host ram: " + str(host['RAM']) + " host cpu "+ str(host['CPUs']))
        host_ram_after_200_percent_overcommitment = math.floor((host['RAM'] * 1024) * 2)
        host_cpu_after_200_percent_overcommitment = math.floor(host['CPUs'] * 2)

        logger.debug("ram available: %s cpu available: %s cpu < max cpu: %s" % ((( host_ram_after_200_percent_overcommitment - used_ram) >= RAM), ((host_cpu_after_200_percent_overcommitment - used_cpu) >= vCPU), (vCPU <= host['CPUs']) ))

        if((( host_ram_after_200_percent_overcommitment - used_ram) >= RAM) and ((host_cpu_after_200_percent_overcommitment - used_cpu) >= vCPU) and (vCPU <= host['CPUs'])):
            return host['id']
        else:
            hosts.remove(host)
            
    #If no suitable host found
    raise Exception("No active host is available for a new vm.")

#Returns resources utilization of a host in MB,Count
def host_resources_used(host_id):
    RAM = 0.0
    CPU = 0.0
    vms = current.db((current.db.vm_data.host_id == host_id) & (current.db.vm_data.status != current.VM_STATUS_UNKNOWN) &  (current.db.vm_data.status != current.VM_STATUS_IN_QUEUE)).select()
    logger.debug("vms selected are: " + str(vms))
    for vm_data in vms:
        RAM += vm_data.RAM
        CPU += vm_data.vCPU
    
    return (math.ceil(RAM),math.ceil(CPU))

def check_host_status(host_ip):
    out=commands.getstatusoutput("ping -c 2 -W 1 " + host_ip)[0]
    logger.debug("Host Check command response for %s: %s" %(host_ip, str(out)))
    if(out == 0):
        if check_host_service_status(host_ip):
            return HOST_STATUS_UP
        else:
            return HOST_STATUS_DOWN
    else: 
        return HOST_STATUS_DOWN

def is_host_available(host_ip):
    try:
        execute_remote_cmd(host_ip,'root','pwd')
        return True
    except:
        return False

def get_host_mac_address(host_ip):
    command = "ifconfig -a | grep eth0 | head -n 1"
    ret = execute_remote_cmd(host_ip, 'root',command)#Returns e.g. eth0      Link encap:Ethernet  HWaddr 18:03:73:0d:e4:49
    ret=ret.strip()
    mac_addr = ret[ret.rindex(' '):].lstrip()
    return mac_addr


def get_host_type(host_ip):

    command="virt-what"
    ret=execute_remote_cmd(host_ip, 'root',command)
    return HOST_TYPE_VIRTUAL if ret else HOST_TYPE_PHYSICAL

def check_host_service_status(host_ip):
    #Check libvirt status
    command = "ps -ef | grep libvirtd | grep -v grep  | wc -l"
    ret = execute_remote_cmd(host_ip, 'root',command)
    if ret == 0 :
        logger.error("Critical: Libvirt service is not running on host " + host_ip)
        return False
    #Check OVS status
    command = "service openvswitch-switch status | grep -w 'running' | wc -l"
    ret = execute_remote_cmd(host_ip, 'root',command)
    if ret == 0 :
        logger.error("Critical: OVS switch is not running on host " + host_ip)
        return False
    return True
    
def host_status_sanity_check():
    for host in current.db().select(current.db.host.ALL):
        if host.status != HOST_STATUS_MAINTENANCE:
            host_status=check_host_status(host.host_ip)
            if(host_status != host.status):
                logger.debug("Changing status of " + host.host_name +" to " + str(host_status))
                host.update_record(status=host_status)
                current.db.commit()
                if host_status == HOST_STATUS_DOWN:
                    respawn_dangling_vms(host.id)

# Establishes a read only remote connection to libvirtd
# Finds out all domains running and not running
def get_host_domains(host_ip):
    try:
        conn = libvirt.openReadOnly('qemu+ssh://root@'+host_ip+'/system')
        domains=[]
        for domain_id in conn.listDomainsID():
            domains.append(conn.lookupByID(domain_id))
        
        for name in conn.listDefinedDomains():
            domains.append(conn.lookupByName(name))

        conn.close()
        return domains
    except:
        raise


#Add migrate task to task_queue
def add_migrate_task_to_queue(vm_id, dest_host_id=None, live_migration=None):
    
    params={'vm_id' : vm_id, 'destination_host' : dest_host_id, 'live_migration' : live_migration}

    current.db.task_queue.insert(task_type='Migrate VM',
                         vm_id=vm_id, 
                         requester_id=-1,
                         parameters=params, 
                         priority=1,  
                         status=1)

 
def get_active_hosts():
    
    return current.db(current.db.host.status == HOST_STATUS_UP).select(current.db.host.ALL)


#Respawn the VMs if the host is unexpectedly down 
def respawn_dangling_vms(host_id):

    vms = current.db(current.db.vm_data.host_id == host_id).select(current.db.vm_data.ALL)
    vm_image_location = get_constant('vmfiles_path') + get_constant('vms') + '/%s/%s.qcow2'
    for vm_data in vms:

        logger.debug('Re-spawning VM ' + vm_data.vm_identity)
        #Create a copy of existing image and rename it with '_old' suffix
        storage_type = config.get("GENERAL_CONF","storage_type")
        copy_command = 'ndmpcopy ' if storage_type == current.STORAGE_NETAPP_NFS else 'cp '

        ds_image_location = vm_data.datastore_id.path + get_constant('vms') + '/%s/%s.qcow2'
        command_to_execute = copy_command + ds_image_location%(vm_data.vm_identity, vm_data.vm_identity) + \
                                ' ' + ds_image_location%(vm_data.vm_identity, vm_data.vm_identity+'_old')

        execute_remote_cmd(vm_data.datastore_id.ds_ip,
                           vm_data.datastore_id.username,
                           command_to_execute,
                           vm_data.datastore_id.password)
        logger.debug('Backup copy of the VM image cretaed successfully.')

        vm_properties = {}
        vm_properties['host'] = find_new_host(vm_data.RAM, vm_data.vCPU)
        vm_properties['ram'] = vm_data.RAM
        vm_properties['vcpus'] = vm_data.vCPU
        vm_properties['mac_addr'] = vm_data.mac_addr
        vm_properties['vnc_port'] = vm_data.vnc_port
        vm_properties['template'] = current.db.template[vm_data.template_id]
        vm_properties['vlan_name'] = current.db(current.db.private_ip_pool.private_ip == vm_data.private_ip).select()[0].vlan.name

        # Re-spawn the VM on new host
        launch_vm_on_host(vm_data, vm_image_location%(vm_data.vm_identity, vm_data.vm_identity), vm_properties)
        vm_data.update_record(host_id = vm_properties['host'])

        #Find the most recent snapshot of the given VM; revert to the snapshot
        recent_snapshot = current.db(current.db.snapshot.vm_id == vm_data.id).select(orderby = ~current.db.snapshot.timestamp)[0]
        logger.debug('Reverting VM %s to snapshot %s' %(vm_data.vm_identity, recent_snapshot.snapshot_name))
        revert(dict(vm_id = vm_data.id, snapshot_id = recent_snapshot.id))
