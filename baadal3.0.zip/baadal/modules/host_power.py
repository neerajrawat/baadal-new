# -*- coding: utf-8 -*-
###################################################################################
import libvirt,commands  # @UnusedImport
from libvirt import *  # @UnusedWildImport
from vm_helper import *  # @UnusedWildImport
from helper import *  # @UnusedWildImport

from random import randrange
from host_vms import has_running_vm, migrate_all_vms_from_host
#Host Status
HOST_STATUS_DOWN = 0
HOST_STATUS_UP = 1
HOST_STATUS_MAINTENANCE = 2

HOST_TYPE_PHYSICAL = "Physical"
HOST_TYPE_VIRTUAL = "Virtual"


get_host_name={"10.0.0.5":"baadal_host_1","10.0.0.6":"baadal_host_2","10.0.0.7":"baadal_host_3","10.0.0.8":"baadal_host_4","10.0.0.9":"baadal_host_5","10.0.0.10":"baadal_host_6","10.0.0.11":"baadal_host_7","10.0.0.12":"baadal_host_8","10.0.0.13":"baadal_host_9"}


#Save Power, turn off extra hosts and turn on if required
def host_power_operation():
    logger.debug("\nIn host power operation function\n-----------------------------------\n")
    livehosts = current.db(current.db.host.status == HOST_STATUS_UP).select()
    freehosts=[]
    try:
        for host_data in livehosts:
            if not has_running_vm(host_data.host_ip):
                freehosts.append(host_data.host_ip)
        freehostscount = len(freehosts)
        if(freehostscount == 2):
            logger.debug("Everything is Balanced. Green Cloud :)")
        elif(freehostscount < 2):
            logger.debug("Urgently needed "+str(2-freehostscount)+" more live hosts.")
            newhosts = current.db(current.db.host.status == HOST_STATUS_DOWN).select()[0:(2-freehostscount)] #Select only Shutoff hosts
            for host_data in newhosts:
                logger.debug("Sending magic packet to "+host_data.host_name)
                host_power_up(host_data)
        elif(freehosts > 2):
            logger.debug("Sending shutdown signal to total "+str(freehostscount-2)+" no. of host(s)")
            extrahosts=freehosts[2:]
            for host_data in extrahosts:
                logger.debug("Moving any dead vms to first running host")
                migrate_all_vms_from_host(host_data.host_ip)
                logger.debug("Sending kill signal to " + host_data.host_ip)
                commands.getstatusoutput("ssh root@" + host_data.host_ip + " shutdown -h now")
                host_data.update_record(status=HOST_STATUS_DOWN)
    except:
        log_exception()
    return


def host_power_up(host_data):
    try:
        if host_data.host_type == HOST_TYPE_VIRTUAL:
            host_ip = host_data.host_ip
            execute_remote_cmd(host_ip, 'root', 'virsh start' + get_host_name[host_ip])
        else:                        
            logger.debug('Powering up host with MAC ' + host_data.mac_addr)
            commands.getstatusoutput( "wakeonlan " + host_data.mac_addr)
        
        logger.debug("Host powered up successfully!!!")
    except:
        log_exception()


#Power down the host
def host_power_down(host_data):

    try:
        host_ip = host_data.host_ip
        if host_data.host_type == HOST_TYPE_VIRTUAL:
            output = execute_remote_cmd(host_ip, 'root', 'virsh destroy' + get_host_name[host_ip])
        else:                        
            output = execute_remote_cmd(host_ip, 'root', 'init 0')

        logger.debug(str(output) + ' ,Host shut down successfully !!!')
    except:
        log_exception()

