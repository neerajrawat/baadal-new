if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from helper import get_constant  # @UnusedWildImport
from nat_mapper import create_mapping, remove_mapping


def set_portgroup_in_vm(domain, portgroup, host_ip, vlan_tag):
    
    connection_object = libvirt.open("qemu+ssh://root@" + host_ip + "/system")
    dom = connection_object.lookupByName(domain)
    xml = etree.fromstring(dom.XMLDesc(0))
    source_network_element = xml.find('.//interface/source') 
   
    source_network_string=etree.tostring(source_network_element) 
    logger.debug("Source network is " + source_network_string)

    if source_network_string.find(" network=") != -1:
        logger.debug("Source is set to network adding portgroup to the source tag ")
        source_network_element.set('portgroup', portgroup)  
        logger.debug("Changed source network is " + etree.tostring(source_network_element)) 
    elif source_network_string.find(" bridge=") != -1:
        logger.debug("Source is set to bridge adding <vlan><tag_id> to the interface tag ")
        root_new  = xml.find('.//interface')  
        root_new_vlan= etree.SubElement(root_new, 'vlan') 
        root_new_tag=  etree.SubElement(root_new_vlan, 'tag')
        root_new_tag.set('id',vlan_tag) 
        logger.debug("After append root_new_vlan is " + etree.tostring(root_new_vlan))  
    else:
        logger.debug("Neither VM nor vlan tagId is added in the xml" )  

    domain = connection_object.defineXML(etree.tostring(xml))
    domain.destroy()
    domain.create()
    domain.isActive()
    connection_object.close()
    
def get_private_ip_mac(security_domain_id):
    vlans = current.db(current.db.security_domain.id == security_domain_id)._select(current.db.security_domain.vlan)
    private_ip_pool = current.db((current.db.private_ip_pool.vm_id == None) & (current.db.private_ip_pool.host_id == None) & 
                         (current.db.private_ip_pool.vlan.belongs(vlans))).select(orderby='<random>').first()

    if private_ip_pool:
        return(private_ip_pool.private_ip, private_ip_pool.mac_addr, private_ip_pool.vlan.name,private_ip_pool.vlan.vlan_tag)
    else:
        sd = current.db.security_domain[security_domain_id]
        raise Exception(("Available MACs are exhausted for security domain '%s'." % sd.name))

# Chooses mac address, ip address and vncport for a vm to be installed
def choose_mac_ip(vm_properties):

    if not 'private_ip' in vm_properties:
        private_ip_info = get_private_ip_mac(vm_properties['security_domain'])
        vm_properties['private_ip'] = private_ip_info[0]
        vm_properties['mac_addr']   = private_ip_info[1]
        vm_properties['vlan_name']  = private_ip_info[2] 
        vm_properties['vlan_tag']   = private_ip_info[3]

    if vm_properties['public_ip_req']:
        if 'public_ip' not in vm_properties:
            public_ip_pool = current.db(current.db.public_ip_pool.vm_id == None).select(orderby='<random>').first()
            if public_ip_pool:
                vm_properties['public_ip'] = public_ip_pool.public_ip
            else:
                raise Exception("Available Public IPs are exhausted.")
    else:
        vm_properties['public_ip'] = current.PUBLIC_IP_NOT_ASSIGNED


def choose_mac_ip_vncport(vm_properties):
    
    choose_mac_ip(vm_properties)

    start_range = int(get_constant('vncport_start_range')) 
    end_range = int(get_constant('vncport_end_range'))
    vnc_ports_taken = current.db().select(current.db.vm_data.vnc_port)
    while True:
        random_vnc_port = random.randrange(start_range, end_range, 1)
        if not random_vnc_port in vnc_ports_taken:
            break;
    vm_properties['vnc_port'] = str(random_vnc_port)

