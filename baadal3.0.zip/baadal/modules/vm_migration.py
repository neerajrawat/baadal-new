if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from helper import execute_remote_cmd, get_constant  # @UnusedWildImport
from nat_mapper import create_mapping, remove_mapping
from host_helper import find_new_host

# Migrate domain with snapshots
def migrate_domain_with_snapshots(vm_details, destination_host_ip, domain, domain_snapshots_list, current_snapshot_name, flags, vm_backup_during_migration):

    # XML dump of snapshot(s) of the vm
    logger.debug("Starting to take xml dump of the snapshot(s) of the vm... ")

    if not os.path.exists(vm_backup_during_migration):
            os.makedirs(vm_backup_during_migration)

    for domain_snapshot in domain_snapshots_list:
        logger.debug("snapshot name is " + str(domain_snapshot))
        dump_xml_path = vm_backup_during_migration + '/' + 'dump_' + domain_snapshot
        snapshot_dumpxml_command = 'virsh snapshot-dumpxml %s %s > %s' % ( vm_details.vm_identity, domain_snapshot, dump_xml_path)
        logger.debug("Taking xml dump of" + str(domain_snapshot))
        command_output = execute_remote_cmd(vm_details.host_id.host_ip, 'root', snapshot_dumpxml_command)
        logger.debug(command_output)
        logger.debug("XML dump of " + str(domain_snapshot) + "succeeded.")

    # Delete snapshot(s) of the vm and migrate it to destination host
    logger.debug("Starting to delete snapshots of the vm....")
    for domain_snapshot in domain_snapshots_list:
        snapshot = domain.snapshotLookupByName(domain_snapshot, 0)
        snapshot.delete(0)
    logger.debug("Migrating the vm to destination host...")
    domain.migrateToURI("qemu+ssh://root@" + destination_host_ip + "/system", flags , None, 0)

    # Redefine all the snapshot(s) of the vm on the destination host and set current snapshot
    logger.debug("Starting to redefine all the snapshot(s) of the domain...")
    for domain_snapshot in domain_snapshots_list:
        redefine_xml_path =  vm_backup_during_migration + '/' + 'dump_' + domain_snapshot
        snapshot_redefine_command = 'virsh snapshot-create --redefine %s %s ' % (vm_details.vm_identity, redefine_xml_path)
        command_output = execute_remote_cmd(destination_host_ip, 'root', snapshot_redefine_command)
        logger.debug(command_output)

    snapshot_current_command = 'virsh snapshot-current %s %s' % (vm_details.vm_identity, current_snapshot_name)
    command_output = execute_remote_cmd(destination_host_ip, 'root', snapshot_current_command)
    logger.debug(command_output)

    return

# Delete directory created for storing dumpxml of vm snapshots
def clean_migration_directory(vm_backup_during_migration):

    if os.path.exists(vm_backup_during_migration):
        shutil.rmtree(vm_backup_during_migration)

    return

# Undo the migration 
def undo_migration(vm_details, domain_snapshots_list, current_snapshot_name, vm_backup_during_migration):

    if domain_snapshots_list:
        # Redefine the snapshots of the vm on the source host
        logger.debug("Starting to redefine all the snapshot(s) of the vm on the source host...")
        for domain_snapshot in domain_snapshots_list:
            redefine_xml_path =  vm_backup_during_migration + '/' + 'dump_' + domain_snapshot
            snapshot_redefine_command = 'virsh snapshot-create --redefine %s %s ' % (vm_details.vm_identity, redefine_xml_path)
            command_output = execute_remote_cmd(vm_details.host_id.host_ip, 'root', snapshot_redefine_command, None, True)
            logger.debug(command_output)
        snapshot_current_command = 'virsh snapshot-current %s %s' % (vm_details.vm_identity, current_snapshot_name)
        command_output = execute_remote_cmd(vm_details.host_id.host_ip, 'root', snapshot_current_command, None, True)
        logger.debug(command_output)
    # Delete directory created for storing dumpxml of vm snapshots
    clean_migration_directory(vm_backup_during_migration)

    return


# Migrate domain
def migrate_domain(vm_id, destination_host_id=None, live_migration=False):

    vm_details = current.db.vm_data[vm_id]
    logger.debug("VM DETAILS AND VM_ID %s  %s" %(str(vm_details),str(vm_id)))
    domain_snapshots_list = []
    current_snapshot_name = ''
    vm_migration_directory = get_constant('vm_migration_data')
    vm_backup_during_migration = vm_details.datastore_id.system_mount_point + '/' + vm_migration_directory + '/' + \
                                 vm_details.vm_identity

    if destination_host_id == None:
        destination_host_id = find_new_host(vm_details.RAM, vm_details.vCPU)

    destination_host_ip = current.db.host[destination_host_id]['host_ip']

    flags = VIR_MIGRATE_PEER2PEER|VIR_MIGRATE_PERSIST_DEST|VIR_MIGRATE_UNDEFINE_SOURCE|VIR_MIGRATE_UNSAFE
    if live_migration:
        flags |= VIR_MIGRATE_TUNNELLED|VIR_MIGRATE_LIVE
        
    if vm_details.status == current.VM_STATUS_SUSPENDED:
        logger.debug("Vm is suspended")
        flags |= VIR_MIGRATE_TUNNELLED|VIR_MIGRATE_PAUSED
    elif vm_details.status == current.VM_STATUS_SHUTDOWN:
        logger.debug("Vm is shut off")
        flags |= VIR_MIGRATE_OFFLINE   
    logger.debug("Flags: " + str(flags))   

    try:    
        current_host_connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = current_host_connection_object.lookupByName(vm_details.vm_identity)
        dom_snapshot_names = domain.snapshotListNames(0)
        
        for snapshot in current.db(current.db.snapshot.vm_id == vm_id).select():
            logger.debug("snapshot:" + str(snapshot.snapshot_name))
            domain_snapshots_list.append(snapshot.snapshot_name)
            dom_snapshot_names.remove(snapshot.snapshot_name)
        logger.debug("domain snapshot list is " + str(domain_snapshots_list))
        
        for dom_snapshot in dom_snapshot_names:
            logger.debug("Deleting orphan snapshot %s" %(dom_snapshot))
            snapshot = domain.snapshotLookupByName(dom_snapshot, 0)        
            snapshot.delete(0)
    
        if domain_snapshots_list:
            current_snapshot = domain.snapshotCurrent(0)
            current_snapshot_name = current_snapshot.getName()
            migrate_domain_with_snapshots(vm_details, destination_host_ip, domain, domain_snapshots_list, current_snapshot_name, flags, vm_backup_during_migration)
        else:
            domain.migrateToURI("qemu+ssh://root@" + destination_host_ip + "/system", flags , None, 0)

        current_host_connection_object.close()
        vm_details.update_record(host_id = destination_host_id)
        current.db.commit()
        
        # Delete directory created for storing dumpxml of vm snapshot
        clean_migration_directory(vm_backup_during_migration)

        message = vm_details.vm_identity + " is migrated successfully."
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        undo_migration(vm_details, domain_snapshots_list, current_snapshot_name, vm_backup_during_migration)
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())
 

# Migrates a vm to a new host
def migrate(parameters):

    logger.debug("Inside migrate() function")
    vmid = parameters['vm_id']
    destination_host_id = parameters['destination_host']
    if parameters['live_migration'] == 'on':
        live_migration = True
    else:
        live_migration = False
    return migrate_domain(vmid, destination_host_id, live_migration)


# Migrates cloned vm to new host
def migrate_clone_to_new_host(vm_details, cloned_vm_details, new_host_id_for_cloned_vm,vm_properties):

    try:
        new_host_ip_for_cloned_vm = current.db.host[new_host_id_for_cloned_vm]['host_ip']
        logger.debug("New host ip for cloned vm is: " + str(new_host_ip_for_cloned_vm))
        flags = VIR_MIGRATE_PEER2PEER|VIR_MIGRATE_PERSIST_DEST|VIR_MIGRATE_UNDEFINE_SOURCE|VIR_MIGRATE_OFFLINE|VIR_MIGRATE_UNSAFE
        logger.debug("Clone currently on: " + str(vm_details.host_id.host_ip))
        current_host_connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = current_host_connection_object.lookupByName(cloned_vm_details.vm_identity)
        logger.debug("Starting to migrate cloned vm to host " + str(new_host_ip_for_cloned_vm))
        domain.migrateToURI("qemu+ssh://root@" + new_host_ip_for_cloned_vm + "/system", flags , None, 0)
        logger.debug("Successfully migrated cloned vm to host " + str(new_host_ip_for_cloned_vm))
        cloned_vm_details.update_record(host_id = new_host_id_for_cloned_vm)
        vm_properties['host'] = new_host_id_for_cloned_vm
        return True
    except libvirt.libvirtError,e:
        message = e.get_error_message()
        logger.debug("Error: " + message)
        return False

