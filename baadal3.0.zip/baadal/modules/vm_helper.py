# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from helper import execute_remote_cmd, choose_datastore # @UnusedWildImport
from nat_mapper import create_mapping, remove_mapping
from host_helper import *
from vm_network import choose_mac_ip_vncport, set_portgroup_in_vm
from vm_security_domain import update_security_domain
from vm_disk import attach_disk, serve_extra_disk_request



# Allocates vm properties ( datastore, host, ip address, mac address, vnc port, ram, vcpus)
def allocate_vm_properties(vm_details):
    
    logger.debug("Inside allocate_vm_properties()...")
    vm_properties = {}

    vm_properties['datastore'] = choose_datastore()
    logger.debug("Datastore selected is: " + str(vm_properties['datastore']))

    vm_properties['host'] = find_new_host(vm_details.RAM, vm_details.vCPU)
    logger.debug("Host selected is: " + str(vm_properties['host']))

    vm_properties['public_ip_req'] = False if (vm_details.public_ip == current.PUBLIC_IP_NOT_ASSIGNED) else True
    vm_properties['security_domain'] = vm_details.security_domain
    choose_mac_ip_vncport(vm_properties)

    logger.debug("MAC is : " + str(vm_properties['mac_addr']) + " IP is : " + str(vm_properties['private_ip']) + " VNCPORT is : "  \
                          + str(vm_properties['vnc_port']) + " Vlan tag is " + str(vm_properties['vlan_tag']) )
    
    vm_properties['ram'] = vm_details.RAM
    vm_properties['vcpus'] = vm_details.vCPU

    return vm_properties


# Creates a vm image
def create_vm_image(vm_details, datastore):

    # Creates a directory for the new vm
    vm_directory_path = datastore.system_mount_point + '/' + get_constant('vms') + '/' + vm_details.vm_identity
    logger.debug("Creating vm directory...")
    if not os.path.exists (vm_directory_path):
        os.makedirs(vm_directory_path)
    else:
        raise Exception("Directory with same name as vmname already exists.")

    # Finds the location of template image that the user has requested for its vm.               
    template = current.db.template[vm_details.template_id]
    vm_image_name = vm_directory_path + '/' + vm_details.vm_identity + '.qcow2'


    template_location = datastore.system_mount_point + '/' + get_constant('templates_dir') + '/' + template.hdfile
    rc = os.system("cp %s %s" % (template_location, vm_image_name))

    if rc != 0:
        logger.error("Copy not successful")
        raise Exception("Copy not successful")
    else:
        logger.debug("Copied successfully")

    
    """

    # Copies the template image from its location to new vm directory
    storage_type = config.get("GENERAL_CONF","storage_type")

    copy_command = 'ndmpcopy ' if storage_type == current.STORAGE_NETAPP_NFS else 'cp '
    #template_dir = get_constant('vm_templates_datastore')
    template_dir = template.datastore_id.path
    logger.debug(template_dir)
    
    logger.debug("Copy in progress when storage type is " + str(storage_type))
    command_to_execute = copy_command + template_dir + '/' + get_constant("templates_dir") + '/' +  \
                         template.hdfile + ' ' + datastore.path + '/' + get_constant('vms') + '/' + \
                         vm_details.vm_identity
    logger.debug("ndmpcopy command: " + str(command_to_execute))
    command_output = execute_remote_cmd(datastore.ds_ip, datastore.username, command_to_execute, datastore.password)
    logger.debug(command_output)
    logger.debug("Copied successfully.")
      

    try:
        vm_template_name = datastore.system_mount_point + '/' + get_constant('vms') + '/' + vm_details.vm_identity + '/' + template.hdfile
        os.rename(vm_template_name, vm_image_name)
        logger.debug("Template renamed successfully")
    except:
        logger.debug("Template rename not successful")
        raise Exception("Template rename not successful")
    """
    return (template, vm_image_name)

# Determines an install command for vm
def get_install_command(vm_details, vm_image_location, vm_properties):

    template = vm_properties['template']
    bus = ',bus=virtio'
    optional = ' --import --os-type=' + template.os
    model = ',model=virtio'
    if (template.arch != 'amd64' and template.os == 'Linux'):
        optional = optional + ' --arch=' + template.arch + ' '
  
    format_command = ''
    if (template.type == 'QCOW2'):
        format_command = ',format=qcow2'
    
    if (template.os == 'Windows'):
        bus = ''
        model = ''


    install_command = 'virt-install \
                     --name=' + vm_details.vm_identity + ' \
                     --ram=' + str(vm_properties['ram']) + ' \
                     --vcpus=' + str(vm_properties['vcpus']) + optional + ' \
                     --disk path=' + vm_image_location + format_command + bus + ',cache=none' + ' \
                     --network network='+current.LIBVIRT_NETWORK + model + ',mac=' + vm_properties['mac_addr'] + ' \
                     --graphics vnc,port=' + vm_properties['vnc_port'] + ',listen=0.0.0.0,password=duolc \
                     --noautoconsole \
                     --description \
                     --autostart \
                     --force' 

    return install_command 

# Generates xml
def generate_xml(diskpath,target_disk):

    root_element = etree.Element('disk',attrib = {'type':'block','device':'disk'})
    etree.SubElement(root_element, 'driver',attrib = {'name':'qemu','cache':'none', 'type':'qcow2'})
    etree.SubElement(root_element, 'source', attrib = {'dev':diskpath})
    etree.SubElement(root_element, 'target', attrib = {'dev': target_disk})

    return (etree.tostring(root_element))

# Launches a vm on host
def launch_vm_on_host(vm_details, vm_image_location, vm_properties):

    attach_disk_status_message = ''
    install_command = get_install_command(vm_details, vm_image_location, vm_properties)  
    # Starts installing a vm
    host_ip = current.db.host[vm_properties['host']].host_ip
    logger.debug("Installation started...")
    logger.debug("Host is "+ host_ip)
    logger.debug("Installation command : " + install_command)
    command_output = execute_remote_cmd(host_ip, 'root', install_command)
    logger.debug(command_output)
    logger.debug("Starting to set portgroup in vm...")
    set_portgroup_in_vm(vm_details['vm_identity'],vm_properties['vlan_name'],host_ip,vm_properties['vlan_tag'])
    logger.debug("Portgroup set in vm")

    # Serving HDD request
    if (int(vm_details.extra_HDD) != 0):
        if (serve_extra_disk_request(vm_details, vm_details.extra_HDD, host_ip, new_vm = True)):
            message = "Attached extra disk successfully."
            attach_disk_status_message += message
            logger.debug(message)
        else:
            attach_disk_status_message += "Attached extra disk failed."
    return attach_disk_status_message

# Checks if a newly created vm is defined
def check_if_vm_defined(hostip, vmname):

    vm_defined = False
    try:
        connection_object = libvirt.openReadOnly('qemu+ssh://root@'+ hostip +'/system')
        domain = connection_object.lookupByName(vmname)
        if domain.ID() in connection_object.listDomainsID():
            vm_defined = True
        connection_object.close()
        return vm_defined
    except:
        return False

# Frees vm properties
def free_vm_properties(vm_details, vm_properties):

    logger.debug("VM installation fails..Starting to free vm properties")

    if vm_properties:
        host_ip_of_vm = current.db.host[vm_properties['host']].host_ip
        logger.debug("Host IP of vm is " + str(host_ip_of_vm))
        if check_if_vm_defined(host_ip_of_vm, vm_details.vm_identity):
            connection_object = libvirt.open('qemu+ssh://root@'+ host_ip_of_vm +'/system')
            domain = connection_object.lookupByName(vm_details.vm_identity)
            logger.debug("Starting to delete vm from host..")
            domain.destroy()
            domain.undefine()
            connection_object.close()
            logger.debug("VM deleted.")

    current.db(current.db.attached_disks.vm_id == vm_details.id).delete() 

    vm_directory_path = vm_properties['datastore'].system_mount_point + '/' + get_constant('vms') + '/' + vm_details.vm_identity

    vm_extra_disk_dir_path = vm_properties['datastore'].system_mount_point + '/' + get_constant('extra_disks_dir') + '/' + vm_properties['datastore'].ds_name + '/' + vm_details.vm_identity
    if os.path.exists (vm_directory_path):
        logger.debug("Starting to delete vm directory.")
        shutil.rmtree(vm_directory_path)
    if os.path.exists (vm_extra_disk_dir_path):
        logger.debug("Starting to delete vm extra disk directory.")
        shutil.rmtree(vm_extra_disk_dir_path)
    return
    

# Updates db after a vm is installed successfully
def update_db_after_vm_installation(vm_details, vm_properties, parent_id = None):

    logger.debug("Starting to update db after vm installation..")
    hostid = vm_properties['host']
    datastore = vm_properties['datastore']
    template_hdd = vm_properties['template'].hdd
    logger.debug("Inside update db after installation")
    logger.debug(str(hostid))

    # Updating the used entry of datastore
    current.db(current.db.datastore.id == datastore.id).update(used = int(datastore.used) + int(vm_details.extra_HDD) +        
                                                                int(template_hdd))

    current.db(current.db.private_ip_pool.private_ip == vm_properties['private_ip']).update(vm_id = vm_details.id)
    if vm_properties['public_ip_req']:
        current.db(current.db.public_ip_pool.public_ip == vm_properties['public_ip']).update(vm_id = vm_details.id)
    # vm_status (function : status) :- (install : running) ; (clone : shutdown)
    if parent_id:
        vm_status = current.VM_STATUS_SHUTDOWN
    else:
        vm_status = current.VM_STATUS_RUNNING

    # Update vm_data table
    current.db(current.db.vm_data.id == vm_details.id).update( host_id = hostid, 
                                                               extra_HDD = vm_details.extra_HDD,
                                                               datastore_id = datastore.id, 
                                                               private_ip = vm_properties['private_ip'], 
                                                               vnc_port = vm_properties['vnc_port'],
                                                               mac_addr = vm_properties['mac_addr'],
                                                               public_ip = vm_properties['public_ip'], 
                                                               start_time = get_datetime(), 
                                                               parent_id = parent_id,
                                                               status = vm_status)

    logger.debug("Updated db")    
    return


# Installs a vm
def install(parameters):
 
        vmid = parameters['vm_id']
        logger.debug("In install() function...")
        vm_details = current.db.vm_data[vmid]
        vm_properties = None

        try:
            # Fetches vm details from vm_data table
            logger.debug("VM details are: " + str(vm_details))
    
            # Calling allocate_vm_properties function
            vm_properties = allocate_vm_properties(vm_details)

            # Calling create_vm_image function
            (vm_properties['template'], vm_image_location) = create_vm_image(vm_details, vm_properties['datastore'])
         
            # Calling launch_vm_on_host
            attach_disk_status_message = launch_vm_on_host(vm_details, vm_image_location, vm_properties)       

            # Checking if vm has been installed successfully
            assert(check_if_vm_defined(current.db.host[vm_properties['host']].host_ip, vm_details.vm_identity)), "VM is not installed. Check logs."

            if vm_properties['public_ip_req']:
                create_mapping(vm_properties['public_ip'], vm_properties['private_ip'])

            # Update database after vm installation
            update_db_after_vm_installation(vm_details, vm_properties) 

            message = "VM is installed successfully." + attach_disk_status_message
            logger.debug("Task Status: SUCCESS Message: %s " % message)

            return (current.TASK_QUEUE_STATUS_SUCCESS, message)                    

        except:
            if vm_properties != None:         
                free_vm_properties(vm_details, vm_properties)
            logger.debug("Task Status: FAILED Error: %s " % log_exception())
            return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Starts a vm
def start(parameters):
    
    logger.debug("Inside start() function")
    vm_id = parameters['vm_id']
    vm_details = current.db.vm_data[vm_id]
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        if domain.info()[0] == VIR_DOMAIN_RUNNING:
            raise Exception("VM is already running. Check vm status on host.")
        domain.create()
        connection_object.close()  
        current.db(current.db.vm_data.id == vm_id).update(status = current.VM_STATUS_RUNNING)
        message = vm_details.vm_identity + " is started successfully."
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Suspends a vm
def suspend(parameters):

    logger.debug("Inside suspend() function")
    vm_id = parameters['vm_id']
    vm_details = current.db.vm_data[vm_id]
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        if domain.info()[0] == VIR_DOMAIN_PAUSED:
            raise Exception("VM is already paused. Check vm status on host.")
        domain.suspend()
        connection_object.close()
        current.db(current.db.vm_data.id == vm_id).update(status = current.VM_STATUS_SUSPENDED)       
        message = vm_details.vm_identity + " is suspended successfully." 
        logger.debug("Task Status: SUCCESS Message: %s " % message)     
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Resumes a vm
def resume(parameters):

    logger.debug("Inside resume() function")
    vm_id = parameters['vm_id']
    vm_details = current.db.vm_data[vm_id]
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        if domain.info()[0] == VIR_DOMAIN_RUNNING:
            raise Exception("VM is already running. Check vm status on host.")
        domain.resume()
        connection_object.close()
        current.db(current.db.vm_data.id == vm_id).update(status = current.VM_STATUS_RUNNING) 
        message = vm_details.vm_identity + " is resumed successfully."
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Destroys a vm forcefully
def destroy(parameters):

    logger.debug("Inside destroy() function")
    vm_id = parameters['vm_id']
    vm_details = current.db.vm_data[vm_id]
    logger.debug(str(vm_details))
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        if domain.info()[0] == VIR_DOMAIN_SHUTOFF:
            raise Exception("VM is already shutoff. Check vm status on host.")
        domain.destroy()
        connection_object.close()
        current.db(current.db.vm_data.id == vm_id).update(status = current.VM_STATUS_SHUTDOWN) 
        message = vm_details.vm_identity + " is destroyed successfully."
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Function to clean up database after vm deletion
def clean_up_database_after_vm_deletion(vm_details):
    
    logger.debug("Inside clean up database after vm deletion () function...")

    # moving vm image folder to archives folder
    archive_directory_path = vm_details.datastore_id.system_mount_point + '/' + get_constant('archives_dir')
    if not os.path.exists(archive_directory_path):
            os.makedirs(archive_directory_path)
    source_file = vm_details.datastore_id.system_mount_point + '/' + get_constant('vms') + '/' + vm_details.vm_identity
    archive_filename = vm_details.vm_identity + str(get_datetime())
    logger.debug(archive_filename)
    destination_file = archive_directory_path  + '/' + archive_filename
    shutil.move(source_file, destination_file)

    # removing hdd 
    vm_extra_disks_directory_path =  vm_details.datastore_id.system_mount_point + '/' + get_constant('extra_disks_dir') + '/' + \
                                    vm_details.datastore_id.ds_name + "/" + vm_details.vm_identity      
    if os.path.exists(vm_extra_disks_directory_path):
        shutil.rmtree(vm_extra_disks_directory_path)

    # updating the used entry of database
    current.db(current.db.datastore.id == vm_details.datastore_id).update(used = int(vm_details.datastore_id.used) -  \
                                                          (int(vm_details.extra_HDD) + int(vm_details.template_id.hdd)))
    # deleting entry of extra disk of vm
    current.db(current.db.attached_disks.vm_id == vm_details.id).delete()

    logger.debug("Database cleaned")

       
# Deletes a vm
def delete(parameters):

    logger.debug("Inside delete() function")
    vm_id = parameters['vm_id']
    vm_details = current.db.vm_data[vm_id]
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        logger.debug(str(vm_details.status))
        if (vm_details.status == current.VM_STATUS_RUNNING or vm_details.status == current.VM_STATUS_SUSPENDED):
            logger.debug("Vm is not shutoff. Shutting it off first.")
            domain.destroy()
        logger.debug("Starting to delete it...")
        domain.undefineFlags(VIR_DOMAIN_UNDEFINE_SNAPSHOTS_METADATA )
        connection_object.close()
        if vm_details.public_ip != current.PUBLIC_IP_NOT_ASSIGNED:
            remove_mapping(vm_details.public_ip, vm_details.private_ip)
        message = vm_details.vm_identity + " is deleted successfully."
        logger.debug(message)
        clean_up_database_after_vm_deletion(vm_details)
        current.db(current.db.vm_data.id == vm_id).delete()
        current.db.commit()
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())


# Edits vm configuration
def edit_vm_config(parameters):

    logger.debug("Inside edit vm config() function")
    vm_id = parameters['vm_id']    
    vm_details = current.db.vm_data[vm_id]
    message = ""
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)

        if 'vcpus' in parameters:
            new_vcpus = int(parameters['vcpus'])
            domain.setVcpusFlags(new_vcpus, VIR_DOMAIN_VCPU_MAXIMUM)
            domain.setVcpusFlags(new_vcpus, VIR_DOMAIN_AFFECT_CONFIG)
            message += "Edited vCPU successfully."
            current.db(current.db.vm_data.id == vm_id).update(vCPU = new_vcpus)

        if 'ram' in parameters:
            new_ram = int(parameters['ram']) * 1024
            logger.debug(str(new_ram))
            domain.setMemoryFlags(new_ram, VIR_DOMAIN_MEM_MAXIMUM)
            domain.setMemoryFlags(new_ram, VIR_DOMAIN_AFFECT_CONFIG)
            message +=  " And edited RAM successfully."
            current.db(current.db.vm_data.id == vm_id).update(RAM = int(parameters['ram']))
            
        if 'public_ip' in parameters:
            enable_public_ip = parameters['public_ip']
            if enable_public_ip:
                public_ip_pool = current.db(current.db.public_ip_pool.vm_id == None).select(orderby='<random>').first()
                if public_ip_pool:
                    create_mapping(public_ip_pool.public_ip, vm_details.private_ip)
                    current.db.public_ip_pool[public_ip_pool.id] = dict(vm_id=vm_id)
                    current.db.vm_data[vm_id] = dict(public_ip=public_ip_pool.public_ip)
                    message += "Edited Public IP successfully."
                    
                else:
                    raise Exception("Available Public IPs are exhausted.")
            else:
                remove_mapping(vm_details.public_ip, vm_details.private_ip)
                current.db(current.db.public_ip_pool.public_ip == vm_details.public_ip).update(vm_id = None)
                current.db.vm_data[vm_id] = dict(public_ip=current.PUBLIC_IP_NOT_ASSIGNED)
        
        if 'security_domain' in parameters:
            logger.debug('Updating security domain')
            xmlfile = update_security_domain(vm_details, parameters['security_domain'], domain.XMLDesc(0))
            domain = connection_object.defineXML(xmlfile)
            if domain.isActive():
                domain.reboot(0)
            message += "Edited security domain successfully"

        connection_object.close()
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())


def get_vm_image_location(datastore_id, vm_identity):

    datastore = current.db.datastore[datastore_id]
    vm_directory_path = datastore.system_mount_point + '/' + get_constant('vms') + '/' + vm_identity
    vm_image_name = vm_directory_path + '/' + vm_identity + '.qcow2'
    
    image_present = True if os.path.exists(vm_image_name) else False
    
    return (vm_image_name, image_present)


#Launch existing VM image
def launch_existing_vm_image(vm_details):
    
    logger.debug('Launch existing VM image')
    vm_properties = {}
    vm_properties['ram'] = vm_details.RAM
    vm_properties['vcpus'] = vm_details.vCPU
    vm_properties['mac_addr'] = vm_details.mac_addr
    vm_properties['security_domain'] = vm_details.security_domain
    
    #If Private IP was already chosen previously and DHCP entry is done
    if vm_details.private_ip != None:
        private_ip_info = current.db.private_ip_pool(private_ip = vm_details.private_ip)
        if private_ip_info:
            vm_properties['private_ip'] = private_ip_info.private_ip
            vm_properties['mac_addr'] = private_ip_info.mac_addr
            vm_properties['vlan_name']  = private_ip_info.vlan.name
            vm_properties['vlan_tag'] = private_ip_info.vlan.vlan_tag
    
    if vm_details.public_ip == current.PUBLIC_IP_NOT_ASSIGNED:
        vm_properties['public_ip_req'] = False
    else:
        vm_properties['public_ip_req'] = True
        if vm_details.public_ip != None:
            vm_properties['public_ip'] = vm_details.public_ip

    choose_mac_ip_vncport(vm_properties)

    vm_properties['template'] = current.db.template[vm_details.template_id]
    vm_properties['datastore'] = current.db.datastore[vm_details.datastore_id]
    vm_properties['host'] = find_new_host(vm_details.RAM, vm_details.vCPU)
    
    (vm_image_name, image_present) = get_vm_image_location(vm_details.datastore_id, vm_details.vm_identity)
    if image_present:
        launch_vm_on_host(vm_details, vm_image_name, vm_properties)
        
        #Check if extra disk needs to be attached
        attached_disks = current.db((current.db.attached_disks.vm_id == vm_details.id)).select()
        if attached_disks:
            #Extra disk to be attached to the VM
            host_ip = current.db.host[vm_properties['host']].host_ip
            disk_counter = 1
            for attached_disk in attached_disks:
                disk_size = attach_disk(vm_details, attached_disk.attached_disk_name, host_ip, disk_counter, True)
                current.db(current.db.attached_disks.vm_id == attached_disk.vm_id and 
                           current.db.attached_disks.attached_disk_name==attached_disk.attached_disk_name
                           ).update(capacity = disk_size)
                vm_details.extra_HDD += disk_size
                disk_counter += 1
                
        #Create mapping of Private_IP and Public_IP
        if vm_properties['public_ip_req']:
            create_mapping(vm_properties['public_ip'], vm_properties['private_ip'])

        update_db_after_vm_installation(vm_details, vm_properties)
        
    
