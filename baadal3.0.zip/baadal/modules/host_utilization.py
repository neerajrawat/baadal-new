import os, re, time, rrdtool, libvirt
from xml.etree import ElementTree
from log_handler import rrd_logger
from gluon import IMG, URL, current


VM_UTIL_10_MINS = 1
VM_UTIL_24_HOURS = 2
VM_UTIL_ONE_WEEK = 3
VM_UTIL_ONE_MNTH = 4
VM_UTIL_ONE_YEAR = 5

STEP         = 300
TIME_DIFF_MS = 550

"""Uses iostat tool to capture CPU statistics of host"""
def get_host_cpu_usage(host_ip):
    rrd_logger.info("inside cpu")
    command = "iostat -c | sed '1,2d'"
    command_output = execute_remote_cmd(host_ip, 'root', command, None,  True)
    rrd_logger.debug(type(command_output))
    cpu_stats = re.split('\s+', command_output[1])
    rrd_logger.debug(cpu_stats)
    rrd_logger.info("CPU stats of host %s is %s" % ( host_ip, (cpu_stats[1] + cpu_stats[2] + cpu_stats[3])))
    return (float(cpu_stats[1]) + float(cpu_stats[2]) + float(cpu_stats[3]))

"""Uses iostat tool to capture input/output statistics for host"""
def get_host_disk_usage(host_ip):
    rrd_logger.info("inside disk")
    command = "iostat -d | sed '1,2d'"
    command_output = execute_remote_cmd(host_ip, 'root', command, None, True)
    disk_stats = re.split('\s+', command_output[1])
    rrd_logger.info("Disk stats of host %s is dr: %s dw: %s" % (host_ip, disk_stats[2], disk_stats[3]))  
    return [float(disk_stats[2]), float(disk_stats[3])]

"""Uses top command to capture memory usage for host"""
def get_host_mem_usage(host_ip):
    rrd_logger.info("inside mem")
    command = "top -b -n1 | grep 'Mem'"
    command_output = execute_remote_cmd(host_ip, 'root', command, None, True)
    rrd_logger.info(command_output)
    if "+" in command_output[0]:
        mem_stats = re.split('\s+', command_output[0])[3]
    else:
        mem_stats =re.split('\s+', command_output[0])[4]
    rrd_logger.info(mem_stats)
    used_mem_in_kb = int(mem_stats[:-1])
    rrd_logger.info("Mem stats of host %s is %s" % (host_ip, used_mem_in_kb))
    return used_mem_in_kb

"""Uses ifconfig command to capture network usage for host"""
def get_host_nw_usage(host_ip):
    rrd_logger.info("inside nw")
    command = "ifconfig baadal-br-int | grep 'RX bytes:'"
    command_output = execute_remote_cmd(host_ip, 'root', command, None, True)
    rrd_logger.info(command_output)
    nw_stats = re.split('\s+', command_output[0])
    rx = int(re.split(':', nw_stats[2])[1])
    tx = int(re.split(':', nw_stats[6])[1])
    rrd_logger.info("Disk stats of host %s is rx: %s tx: %s" % (host_ip, rx, tx))
    return [rx, tx]

def get_host_resources_usage(host_ip):

    host_cpu_usage = get_host_cpu_usage(host_ip)
    rrd_logger.info(host_cpu_usage)
    host_disk_usage = get_host_disk_usage(host_ip)
    rrd_logger.info(host_disk_usage)
    host_mem_usage = get_host_mem_usage(host_ip)
    rrd_logger.info(host_mem_usage)
    host_nw_usage = get_host_nw_usage(host_ip)
    rrd_logger.info(host_nw_usage)

    host_usage = {'cpu' : host_cpu_usage} #percent cpu usage
    host_usage.update({'dr' : host_disk_usage[0]*1024}) #Bytes/s
    host_usage.update({'dw' : host_disk_usage[1]*1024})
    host_usage.update({'ram' : host_mem_usage*1024}) #Bytes
    host_usage.update({'rx' : host_nw_usage[0]}) #in Bytes
    host_usage.update({'tx' : host_nw_usage[1]}) #in Bytes

    rrd_logger.info("Host %s stats:  %s" % (host_ip, host_usage))
    return host_usage



