if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from helper import get_datetime # @UnusedWildImport
from network_helper import is_pingable

# Checks if a vm has snapshot(s)    
def vm_has_snapshots(vm_id):
    if (current.db(current.db.snapshot.vm_id == vm_id).select()):
        return True
    else:
        return False


# Snapshots a vm
def snapshot(parameters):

    logger.debug("Inside snapshot() function")
    vm_id = parameters['vm_id']
    snapshot_type = parameters['snapshot_type']
    try:

        vm_details = current.db.vm_data[vm_id]

        if is_pingable(str(vm_details.private_ip)):

            logger.debug("VM is pingable. Starting to start with snapshotting...")
            if snapshot_type != current.SNAPSHOT_USER:
                snapshots = current.db((current.db.snapshot.vm_id == vm_id) & (current.db.snapshot.type == snapshot_type)).select()
                #Delete the existing Daily/Monthly/Yearly snapshot
                for snapshot_cron in snapshots:
                    logger.debug(snapshot_cron)
                    delete_snapshot({'vm_id':vm_id, 'snapshot_id':snapshot_cron.id})

            snapshot_name = get_datetime().strftime("%I:%M%p_%B%d,%Y")
            connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
            domain = connection_object.lookupByName(vm_details.vm_identity)
            xmlDesc = "<domainsnapshot><name>%s</name></domainsnapshot>" % (snapshot_name)
            domain.snapshotCreateXML(xmlDesc, 0)
            connection_object.close()
            message = "Snapshotted successfully."
            current.db.snapshot.insert(vm_id = vm_id, datastore_id = vm_details.datastore_id, snapshot_name = snapshot_name, type = snapshot_type)
            logger.debug("Task Status: SUCCESS Message: %s " % message)
            return (current.TASK_QUEUE_STATUS_SUCCESS, message)

        else:
                
            message = "Unable to ping VM before snapshoting: %s" % (vm_details.private_ip)
            raise Exception("Unable to ping VM before snapshotting: %s" % (vm_details.private_ip))

    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Reverts to snapshot
def revert(parameters):
    
    logger.debug("Inside revert snapshot() function")
    try:
        vm_id = parameters['vm_id']
        snapshotid = parameters['snapshot_id']
        vm_details = current.db.vm_data[vm_id]
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        snapshot_name = current.db(current.db.snapshot.id == snapshotid).select().first()['snapshot_name']
        snapshot = domain.snapshotLookupByName(snapshot_name, 0)
        domain.revertToSnapshot(snapshot, 0)
        connection_object.close()
        message = "Reverted to snapshot successfully."
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())

# Deletes a snapshot
def delete_snapshot(parameters):

    logger.debug("Inside delete snapshot() function")
    vm_id = parameters['vm_id']
    snapshotid = parameters['snapshot_id']
    vm_details = current.db.vm_data[vm_id]
    logger.debug(str(vm_details))
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + vm_details.host_id.host_ip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        snapshot_name = current.db(current.db.snapshot.id == snapshotid).select().first()['snapshot_name']
        
        snapshot = None
        try:
            snapshot = domain.snapshotLookupByName(snapshot_name, 0)
        except libvirtError:
            logger.debug("Snapshot %s not found" %(snapshot_name))
        
        if snapshot != None:
            snapshot.delete(0)        

        connection_object.close()

        message = "Deleted snapshot successfully."
        logger.debug(message)
        current.db(current.db.snapshot.id == snapshotid).delete()
        logger.debug("Task Status: SUCCESS Message: %s " % message)
        return (current.TASK_QUEUE_STATUS_SUCCESS, message)
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())


