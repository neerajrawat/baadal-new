# -*- coding: utf-8 -*-
###################################################################################

import os, re, random
import paramiko
from gluon.validators import Validator
from gluon import current
from log_handler import logger
from helper import execute_remote_cmd


#Checks if string represents 4 octets seperated by decimal.
def is_valid_ipv4(value):
    regex = re.compile(
        '^(([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.){3}([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])$')
    return regex.match(value)

#Validates each IP string, checks if first three octets are same; and the last octet has a valid range.
def validate_ip_range(ipFrom, ipTo):
    
    if is_valid_ipv4(ipFrom) and is_valid_ipv4(ipTo):
        ip1 = ipFrom.split('.')
        ip2 = ipTo.split('.')
        if ip1[0] == ip2[0] and ip1[1] == ip2[1] and ip1[2] == ip2[2] and int(ip1[3]) < int(ip2[3]):
            return True
    return False

#Get List of IPs in a validated IP range
def get_ips_in_range(ipFrom, ipTo):
    
    ip_addr_lst = []
    ip1 = ipFrom.split('.')
    ip2 = ipTo.split('.')
    idx =  - (len(ip1[3]))
    subnet = str(ipFrom[:idx])
    for x in range(int(ip1[3]), int(ip2[3])+1):
        ip_addr_lst.append(subnet + str(x))
    return ip_addr_lst


# Generates MAC address
def generate_random_mac():
    MAC_GEN_FIRST_BIT=0xa2
    MAC_GEN_FIXED_BITS=3
    
    mac = [MAC_GEN_FIRST_BIT]
    i = 1
    while i <  MAC_GEN_FIXED_BITS:
        mac.append(0x00)
        i += 1
    while i <  6:    
        mac.append(random.randint(0x00, 0xff))
        i += 1
    return (':'.join(map(lambda x: "%02x" % x, mac))).upper()
    

#Creates bulk entry into DHCP
# Gets list of tuple containing (host_name, mac_addr, ip_addr)
def create_dhcp_bulk_entry(dhcp_info_list):
    
    if len(dhcp_info_list) == 0: return
    dhcp_ip = config.get("GENERAL_CONF","dhcp_ip")
    entry_cmd = ""
    
    for dhcp_info in dhcp_info_list:
        host_name = dhcp_info[0] if dhcp_info[0] != None else ('IP_' + dhcp_info[2].replace(".", '_'))
        dhcp_cmd = '''
            ip_present=$(grep 'host %s ' /etc/dhcp/dhcpd.conf)
            if test -z "$ip_present"; then
                echo "host %s {\n\thardware ethernet %s;\n\tfixed-address %s;\n}\n" >> /etc/dhcp/dhcpd.conf
            else
                echo %s
            fi
            ''' %(host_name, host_name, dhcp_info[1], dhcp_info[2], dhcp_info[2])

        entry_cmd += dhcp_cmd
        
    restart_cmd = "/etc/init.d/isc-dhcp-server restart"

    execute_remote_cmd(dhcp_ip, 'root', entry_cmd)
    execute_remote_cmd(dhcp_ip, 'root', restart_cmd)

#Creates single entry into DHCP
def create_dhcp_entry(host_name, mac_addr, ip_addr):
    
    dhcp_info_list = [(host_name, mac_addr, ip_addr)]
    create_dhcp_bulk_entry(dhcp_info_list)

#Removes entry from DHCP
def remove_dhcp_entry(host_name, mac_addr, ip_addr):

    host_name = host_name if host_name != None else ('IP_' + ip_addr.replace(".", '_'))
    dhcp_ip = config.get("GENERAL_CONF","dhcp_ip")
    if mac_addr != None:
        entry_cmd = "sed -i '/host.*%s.*{/ {N;N;N; s/host.*%s.*{.*hardware.*ethernet.*%s;.*fixed-address.*%s;.*}//g}' /etc/dhcp/dhcpd.conf" %(host_name, host_name, mac_addr, ip_addr)
    else:
        entry_cmd = "sed -i '/host.*%s.*{/ {N;N;N; s/host.*%s.*{.*}//g}' /etc/dhcp/dhcpd.conf" %(host_name, host_name)

    restart_cmd = "/etc/init.d/isc-dhcp-server restart"
    
    execute_remote_cmd(dhcp_ip, 'root', entry_cmd)
    execute_remote_cmd(dhcp_ip, 'root', restart_cmd)


def is_pingable(ip):

    command = "ping -c 1 %s" % ip
    response = os.system(command)
    
    return not(response)



"""Custom validator to check if string is a valid mac address"""
class IS_MAC_ADDRESS(Validator):

    regex = re.compile('^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')

    def __init__(self, error_message='enter valid MAC address'):
        self.error_message = error_message

    def __call__(self, value):
        if self.regex.match(value):
            return (value, None)
        else:
            return (value, self.error_message)

