if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from nat_mapper import create_mapping, remove_mapping
from vm_network import get_private_ip_mac

def update_security_domain(vm_details, security_domain_id, xmlDesc=None):
    # fetch new private IP from db from given security domain
    private_ip_info = get_private_ip_mac(security_domain_id)
    # update vm config to add new mac address.
    root = etree.fromstring(xmlDesc)

    mac_elem = root.find("devices/interface[@type='bridge']/mac")
    mac_elem.set('address', private_ip_info[1])

    vlan_tag_elem = root.find("devices/interface[@type='bridge']/vlan/tag")
    vlan_tag_elem.set('id', private_ip_info[2])
    
    # update NAT IP mapping, if public IP present
    if vm_details.public_ip != current.PUBLIC_IP_NOT_ASSIGNED:
        remove_mapping(vm_details.public_ip, vm_details.private_ip)
        create_mapping(vm_details.public_ip, private_ip_info[0])
    
    # update vm_data, private_ip_pool
    current.db(current.db.private_ip_pool.private_ip == vm_details.private_ip).update(vm_id = None)
    current.db(current.db.private_ip_pool.private_ip == private_ip_info[0]).update(vm_id = vm_details.id)
    current.db(current.db.vm_data.id == vm_details.id).update(security_domain = security_domain_id, 
                                                              private_ip = private_ip_info[0], 
                                                              mac_addr = private_ip_info[1])
    
    return etree.tostring(root)

