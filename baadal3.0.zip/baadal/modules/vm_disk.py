if 0:
    from gluon import *  # @UnusedWildImport
###################################################################################

import sys, math, shutil, paramiko, traceback, libvirt, os
import xml.etree.ElementTree as etree
from libvirt import *  # @UnusedWildImport
from helper import choose_datastore


# create_extra_disk_image
def create_extra_disk_image(vm_details, disk_name, size, datastore):

    vm_extra_disks_directory_path = datastore.system_mount_point + '/' + get_constant('extra_disks_dir') + '/' + \
                                    datastore.ds_name + '/' + vm_details.vm_identity

    if not os.path.exists (vm_extra_disks_directory_path):
        logger.debug("Making Directory")          
        os.makedirs(vm_extra_disks_directory_path)

    diskpath = vm_extra_disks_directory_path + '/' + disk_name

    command= "qemu-img create -f qcow2 "+ diskpath + " " + str(size) + "G"
    output = os.system(command)

    return False if output != 0 else True


def get_extra_disk_location(datastore_id, vm_identity, disk_name, get_disk_size=False):

    datastore = current.db.datastore[datastore_id]
    if datastore:
        vm_extra_disks_directory_path = datastore.system_mount_point + '/' + get_constant('extra_disks_dir') + '/' + \
                                        datastore.ds_name + '/' + vm_identity
        ext = '' if disk_name.endswith('.qcow2') else '.qcow2'
        disk_image_path = vm_extra_disks_directory_path + '/' + disk_name + ext
        image_present = True if os.path.exists(disk_image_path) else False
    
        disk_size = 0
        if image_present & get_disk_size:
            command = "qemu-img info " + disk_image_path + " | grep 'virtual size'"
            ret = ret = os.popen(command).read() # Returns e.g. virtual size: 40G (42949672960 bytes)
            disk_size = int(ret[ret.index(':')+1:ret.index('G ')].strip())
            
        return (disk_image_path, image_present, disk_size)
    else:
        return (None, False, 0)


# Attaches a disk with vm
def attach_disk(vm_details, disk_name, hostip, already_attached_disks, new_vm):
   
    try:
        connection_object = libvirt.open("qemu+ssh://root@" + hostip + "/system")
        domain = connection_object.lookupByName(vm_details.vm_identity)
        #already_attached_disks = len(current.db(current.db.attached_disks.vm_id == vm.id).select()) 
        logger.debug("Value of alreadyattached is : " + str(already_attached_disks))
        
        (diskpath, device_present, disk_size) = get_extra_disk_location(vm_details.datastore_id, vm_details.vm_identity, disk_name, True)

        if not device_present:
            raise Exception("Device to be attached %s missing" %(diskpath))
        
        # Attaching disk to vm using libvirt API
        target_disk = "vd" + chr(97 + already_attached_disks + 1)
        logger.debug(target_disk)
        logger.debug("...................")
        xmlDescription = generate_xml(diskpath, target_disk)
        logger.debug(xmlDescription)
        logger.debug("new vm is %s " % new_vm)

        if new_vm:
            logger.debug("Starting to attach disk on new vm request.")
            domain.destroy()
            logger.debug("VM destroyed")
            domain.attachDeviceFlags(xmlDescription, VIR_DOMAIN_AFFECT_CONFIG)
            logger.debug("Disk attached")
            
            logger.debug("Turn on vm")
            domain.create()
            logger.debug("VM started")
            domain.isActive()

        elif vm_details.status == current.VM_STATUS_SHUTDOWN:
            logger.debug("Starting to attach disk while vm is shutdown.")
            domain.attachDeviceFlags(xmlDescription, VIR_DOMAIN_AFFECT_CONFIG) 
            logger.debug("Disk attached")

        else:
            raise Exception("VM is not in shutdown state. Check its status on host")        
        
        xmlfile = domain.XMLDesc(0)
        domain = connection_object.defineXML(xmlfile)
        logger.debug("VM XML redefined")

        connection_object.close()
        return disk_size
    except:
        logger.exception('Exception: ') 
        return 0

# Serves extra disk request and updates db
def serve_extra_disk_request(vm_details, disk_size, host_ip, new_vm = False):

    logger.debug("Starting to serve extra disk request...")
    logger.debug("new vm is %s " % new_vm)
    datastore = choose_datastore()
    already_attached_disks = len(current.db(current.db.attached_disks.vm_id == vm_details.id).select()) 
    disk_name = vm_details.vm_identity + "_disk" + str(already_attached_disks + 1) + ".qcow2"  

    disk_created = create_extra_disk_image(vm_details, disk_name, disk_size, datastore) 
    vm_details.datastore_id = datastore.id

    if disk_created:
        if (attach_disk(vm_details, disk_name, host_ip, already_attached_disks, new_vm)):
            current.db.attached_disks.insert(vm_id = vm_details.id, datastore_id = datastore.id , attached_disk_name = disk_name, capacity = disk_size)
            current.db(current.db.datastore.id == datastore.id).update(used = int(datastore.used) + int(disk_size)) 
            return True

    return False


# Attaches extra disk to VM
def attach_extra_disk(parameters):

    logger.debug("Inside attach extra disk() function")
    vmid = parameters['vm_id']
    disk_size = parameters['disk_size']
    vm_details = current.db.vm_data[vmid]
    logger.debug(str(vm_details))

    try:
        if (serve_extra_disk_request(vm_details, disk_size, vm_details.host_id.host_ip)):
            current.db(current.db.vm_data.id == vmid).update(extra_HDD = vm_details.extra_HDD + disk_size)
            message = "Attached extra disk successfully"
            logger.debug(message)
            return (current.TASK_QUEUE_STATUS_SUCCESS, message) 
        else:
            message = " Your request for additional HDD could not be completed at this moment. Check logs."
            logger.debug("Task Status: SUCCESS Message: %s " % message)
            return (current.TASK_QUEUE_STATUS_FAILED, message) 
    except:
        logger.debug("Task Status: FAILED Error: %s " % log_exception())
        return (current.TASK_QUEUE_STATUS_FAILED, log_exception())



