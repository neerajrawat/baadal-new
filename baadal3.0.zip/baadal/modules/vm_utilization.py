# -*- coding: utf-8 -*-
###################################################################################
""" vm_utilization.py:  Captures utilization data for virtual machines & hosts;  
and stores the information in a RRD database. 
RRD is a Round Robin Database which is created for pre-defined time interval. 
When new data reaches the starting point, it overwrites existing data. The RRDtool 
database is structured in such a way that it needs data at predefined time intervals. 
Then graphs can be directly generated from the information by specifying the 
Consolidation Function.
For more information on rrdtool visit http://oss.oetiker.ch/rrdtool/

Following utilization data is captured for each Host and VM:
Memory
CPU
Network(read & write)
Disk (read & write)

For virtual machines, CPU, network and disk utilization information is fetched from
the respective domain running on the hypervisor. Memory utilization is fetched from  
host, since VMs run as processes on the host.

"""
import os, re, time, rrdtool, libvirt
from xml.etree import ElementTree
from log_handler import rrd_logger
from gluon import IMG, URL, current


VM_UTIL_10_MINS = 1
VM_UTIL_24_HOURS = 2
VM_UTIL_ONE_WEEK = 3
VM_UTIL_ONE_MNTH = 4
VM_UTIL_ONE_YEAR = 5

STEP         = 300
TIME_DIFF_MS = 550


"""Captures memory utilization of a VM from the host.
   VMs run on host as individual processes. Memory utilization of the process is derived."""
def get_dom_mem_usage(dom_name, host_ip):
    
    rrd_logger.debug("Fetching memory usage of domain %s defined on host %s" % (dom_name, host))

    cmd = "output=`ps -ef --sort=start_time | grep '%s.qcow2' | grep -v grep | awk '{print $2}'`;smem -c 'pid pss'| grep $output | awk '{print $2}'" % dom_name
    #"ps aux | grep '\-name " + dom_name + " ' | grep kvm"
    rrd_logger.info(cmd)
    output = execute_remote_cmd(host, "root", cmd, None, True)
    return (int(output[0]))*1024 #return memory in Bytes by default

"""Uses libvirt function to extract interface device statistics for a domain
   to find network usage of virtual machine."""
def get_dom_nw_usage(dom_obj):
    rrd_logger.info("inside network function")
    tree = ElementTree.fromstring(dom_obj.XMLDesc(0))
    rx = 0
    tx = 0

    for target in tree.findall("devices/interface/target"):
        device = target.get("dev")
        stats  = dom_obj.interfaceStats(device)
        rx   += stats[0]
        tx   += stats[4]

    rrd_logger.info("%s%s" % (rx, tx))

    return [rx, tx] #returned value in Bytes by default

"""Uses libvirt function to extract block device statistics for a domain
   to find disk usage of virtual machine."""
def get_dom_disk_usage(dom_obj):
    rrd_logger.info("inside disk usage function")
    tree = ElementTree.fromstring(dom_obj.XMLDesc(0))
    bytesr = 0
    bytesw = 0
    rreq  = 0
    wreq  = 0

    for target in tree.findall("devices/disk/target"):

        device = target.get("dev")
        stats  = dom_obj.blockStats(device)
        rreq   += stats[0]
        bytesr += stats[1]
        wreq   += stats[2]
        bytesw += stats[3]

    rrd_logger.info("rreq: %s bytesr: %s wreq: %s bytesw: %s" % (rreq, bytesr, wreq, bytesw))

    return [bytesr, bytesw] #returned value in Bytes by default

def get_current_dom_resource_usage(dom_obj, host_ip):

    dom_memusage   = get_dom_mem_usage(dom.name(), host_ip)
    dom_nw_usage   = get_dom_nw_usage(dom)
    dom_disk_usage = get_dom_disk_usage(dom)

    dom_stats =      {'rx'     : dom_nw_usage[0]}
    dom_stats.update({'tx'     : dom_nw_usage[1]})
    dom_stats.update({'diskr'   : dom_disk_usage[0]})
    dom_stats.update({'diskw'   : dom_disk_usage[1]})
    dom_stats.update({'memory'  : dom_memusage})
    dom_stats.update({'cputime' : dom.info()[4]})
    dom_stats.update({'cpus'    : dom.info()[3]})

    rrd_logger.info(dom_stats)
    rrd_logger.warn("As we get VM mem usage info from rrs size of the process running on host therefore it is observed that the memused is sometimes greater than max mem specified in case when the VM uses memory near to its mam memory")

    return dom_stats

def get_actual_usage(dom_obj, host_ip):


    dom_name = dom_obj.name()

    dom_stats = get_current_dom_resource_usage(dom_obj, host_ip)

    """Fetch previous domain stat value from cache"""
    prev_dom_stats = current.cache.disk(str(dom_name), lambda:dom_stats, 86400)  # @UndefinedVariable
    """rrd_logger.debug(prev_dom_stats)  """
    rrd_logger.debug("prev_dom_stats for domain %s:%s" % (dom_name,prev_dom_stats))
    rrd_logger.debug("current_dom_stats for domain %s:%s" % (dom_name, dom_stats))
    
    #calulate usage
    usage = {'ram'      : dom_stats['memory']} #ram in Bytes usage
    usage.update({'cpu' : (dom_stats['cputime'] - prev_dom_stats['cputime'])/(float(prev_dom_stats['cpus'])*10000000*STEP)}) #percent cpu usage
    usage.update({'tx'  : (dom_stats['tx'] - prev_dom_stats['tx'])}) #in KBytes
    usage.update({'rx'  : (dom_stats['rx'] - prev_dom_stats['rx'])}) #in KBytes
    usage.update({'dr'  : (dom_stats['diskr'] - prev_dom_stats['diskr'])}) #in KBytes
    usage.update({'dw'  : (dom_stats['diskw'] - prev_dom_stats['diskw'])}) #in KBytes

    current.cache.disk.clear(str(dom_name))  # @UndefinedVariable

    """Cache the current CPU utilization, so that difference can be calculated in next instance"""
    latest_dom_stats = current.cache.disk(str(dom_name), lambda:dom_stats, 86400)        # @UndefinedVariable
    rrd_logger.debug("latest_dom_stats for domain %s:%s" %(dom_name,latest_dom_stats))
   
    return usage 


