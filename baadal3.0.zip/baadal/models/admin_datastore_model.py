###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.log_handler import logger
from applications.baadal.models.common_model import mark_required

def get_manage_datastore_form(req_type):

    db.datastore.id.readable=False # Since we do not want to expose the used field on the grid

    default_sort_order=[db.datastore.id]

    if req_type in ('new','edit'):
        mark_required(db.datastore)
    #Creating the grid object
    form = SQLFORM.grid(db.datastore, orderby=default_sort_order, paginate=ITEMS_PER_PAGE, 
                        csv=False, searchable=False, details=False, showbuttontext=False, maxtextlength=30)
    return form


