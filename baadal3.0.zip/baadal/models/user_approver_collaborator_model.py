# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta
from applications.baadal.models.user_model import get_user_info, add_user_verify_row

def add_faculty_approver(form):

    add_user_verify_row(form, 
                        field_name = 'faculty_user', 
                        field_label = 'Faculty Approver', 
                        verify_function = 'verify_faculty()', 
                        row_id = 'faculty_row',
                        is_required = True)

def validate_approver(form):

    faculty_user_name = request.post_vars.faculty_user
    
    faculty_info = get_user_info(faculty_user_name, [FACULTY])
    if faculty_info != None:
        form.vars.owner_id = faculty_info[0]
        form.vars.status = REQ_STATUS_REQUESTED
    else:
        form.errors.faculty_user='Faculty Approver Username is not valid'


def add_collaborators(form):

    add_user_verify_row(form, 
                        field_name = 'collaborator', 
                        field_label = 'Collaborators', 
                        verify_function = 'check_collaborator()', 
                        verify_label = 'Add',
                        row_id = 'collaborator_row')
