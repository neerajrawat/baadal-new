###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.network_helper import IS_MAC_ADDRESS, create_dhcp_entry, get_ips_in_range, generate_random_mac,\
    remove_dhcp_entry, create_dhcp_bulk_entry, is_valid_ipv4
from applications.baadal.modules.host_helper import is_host_available, get_host_mac_address, get_host_type
from applications.baadal.modules.host_vms import migrate_all_vms_from_host
from applications.baadal.modules.host_resource_details import get_host_cpu, get_host_ram, get_host_hdd, HOST_STATUS_UP, HOST_STATUS_DOWN, HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_power import host_power_up, host_power_down
from applications.baadal.modules.rrd_graph import fetch_rrd_data, VM_UTIL_24_HOURS, VM_UTIL_ONE_WEEK, VM_UTIL_ONE_MNTH, \
    VM_UTIL_ONE_YEAR, VM_UTIL_10_MINS
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_helper import launch_existing_vm_image, get_vm_image_location
from applications.baadal.modules.vm_disk import get_extra_disk_location

def get_manage_public_ip_pool_form():
    db.public_ip_pool.id.readable=False # Since we do not want to expose the id field on the grid
    db.public_ip_pool.vm_id.readable=False

    default_sort_order=[db.public_ip_pool.id]

    #Creating the grid object
    grid = SQLFORM.grid(db.public_ip_pool, orderby=default_sort_order, paginate=ITEMS_PER_PAGE, 
                        csv=False, searchable=False, details=False, showbuttontext=False, 
                        links=[dict(header='Assigned to', body=get_vm_link)])

    if grid.create_form:
        grid.create_form[0].insert(-1, TR(SPAN(
                                        LABEL('Range:'),
                                        INPUT(_name='range',value=False,_type='checkbox', _id='public_ip_pool_range')), SPAN(
                                        'From: ',
                                        INPUT(_name='rangeFrom', _id='public_ip_pool_rangeFrom'),
                                        'To: ', 
                                        INPUT(_name='rangeTo', _id='public_ip_pool_rangeTo')),TD()))
        
        grid.create_form.process()

    return grid

def private_ip_on_delete(private_ip_pool_id):
    private_ip_data = db.private_ip_pool[private_ip_pool_id]
    if private_ip_data.vlan != HOST_VLAN_ID:
        remove_dhcp_entry(None, private_ip_data.mac_addr ,private_ip_data.private_ip)
    
def get_manage_private_ip_pool_form():
    db.private_ip_pool.id.readable=False # Since we do not want to expose the id field on the grid
    db.private_ip_pool.vm_id.readable=False

    default_sort_order=[db.private_ip_pool.id]
    #Creating the grid object
    grid = SQLFORM.grid(db.private_ip_pool, orderby=default_sort_order, paginate=ITEMS_PER_PAGE, 
                        csv=False, searchable=True, details=False, showbuttontext=False, 
                        links=[dict(header='Assigned to', body=get_vm_link)], 
                        ondelete=lambda _table, _id: private_ip_on_delete(_id))

    if grid.create_form:
        grid.create_form[0].insert(-1, TR(SPAN(
                                        LABEL('Range:'),
                                        INPUT(_name='range',value=False,_type='checkbox', _id='private_ip_pool_range')), SPAN(
                                        'From: ',
                                        INPUT(_name='rangeFrom', _id='private_ip_pool_rangeFrom'),
                                        'To: ', 
                                        INPUT(_name='rangeTo', _id='private_ip_pool_rangeTo')),TD()))
        
        grid.create_form.process(onsuccess=lambda form: add_private_ip(form.vars.id))

    return grid

#Add Validated IP addresses that are in range
def add_public_ip_range(rangeFrom, rangeTo):

    failed = 0
    for ip_addr in get_ips_in_range(rangeFrom, rangeTo):
        if(db.public_ip_pool(public_ip=ip_addr)):
            failed += 1
        else:
            db.public_ip_pool.insert(public_ip=ip_addr)
    return failed
    
#Generate mac address and add them with IPs
def add_private_ip_range(rangeFrom, rangeTo, vlan):

    failed = 0
    dhcp_info_list = []
    for ip_addr in get_ips_in_range(rangeFrom, rangeTo):
        mac_address = None
        if vlan != HOST_VLAN_ID:
            while True:
                mac_address = generate_random_mac()
                if not (db.private_ip_pool(mac_addr=mac_address)):break
        
        if(db.private_ip_pool(private_ip=ip_addr)):
            failed += 1
        else:
            db.private_ip_pool.insert(private_ip=ip_addr, mac_addr=mac_address, vlan=vlan)
            if vlan != HOST_VLAN_ID:
                dhcp_info_list.append((None, mac_address, ip_addr))
    
    create_dhcp_bulk_entry(dhcp_info_list)
    
    return failed


#Generate mac address and add them with IP
def add_private_ip(ip_pool_id):

    private_ip_pool = db.private_ip_pool[ip_pool_id]
    if private_ip_pool.vlan != HOST_VLAN_ID:
        mac_address = private_ip_pool.mac_addr
        if mac_address == None:
            while True:
                mac_address = generate_random_mac()
                if not (db.private_ip_pool(mac_addr=mac_address)):break
            #Update generated mac address in DB
            private_ip_pool.update_record(mac_addr=mac_address)

        create_dhcp_entry(None, mac_address, private_ip_pool.private_ip)


def is_ip_assigned(ip_pool_id, is_private):
    if is_private:        
        if not db.private_ip_pool(id=ip_pool_id, vm_id = None, host_id = None):
            return PRIVATE_IP_DELETE_MESSAGE
    else:
        if not db.public_ip_pool(id=ip_pool_id, vm_id = None, host_id = None):
            return PUBLIC_IP_DELETE_MESSAGE

