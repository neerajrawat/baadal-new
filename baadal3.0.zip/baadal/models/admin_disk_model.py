###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.log_handler import logger


def add_extra_disk(form):

    add_user_verify_row(form, 
                        field_name = 'attach_disks', 
                        field_label = 'Attach Extra Disk', 
                        verify_function = 'check_extra_disk()', 
                        verify_label = 'Add',
                        row_id = 'attach_disk_row')
