# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    import gluon
    global auth; auth = gluon.tools.Auth()
    from gluon import db, request, session
    from gluon import *  # @UnusedWildImport
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.helper import log_exception, logger

#Update the dictionary with values specific to pending Attach Disk request tab
def update_attach_disk_request(vm_request, element):
    element['parent_vm_id'] = vm_request.parent_id
    element['extra_HDD'] = str(vm_request.extra_HDD) + 'GB' if vm_request.extra_HDD != None else '-'
    element['attach_disk'] = str(vm_request.attach_disk) + 'GB'
    

