###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.network_helper import IS_MAC_ADDRESS, create_dhcp_entry, get_ips_in_range, generate_random_mac,\
    remove_dhcp_entry, create_dhcp_bulk_entry, is_valid_ipv4
from applications.baadal.modules.host_helper import is_host_available, get_host_mac_address, get_host_type
from applications.baadal.modules.host_vms import migrate_all_vms_from_host
from applications.baadal.modules.host_resource_details import get_host_cpu, get_host_ram, get_host_hdd, HOST_STATUS_UP, HOST_STATUS_DOWN, HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_power import host_power_up, host_power_down
from applications.baadal.modules.rrd_graph import fetch_rrd_data, VM_UTIL_24_HOURS, VM_UTIL_ONE_WEEK, VM_UTIL_ONE_MNTH, \
    VM_UTIL_ONE_YEAR, VM_UTIL_10_MINS
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_helper import launch_existing_vm_image, get_vm_image_location
from applications.baadal.modules.vm_disk import get_extra_disk_location
from applications.baadal.models.common_host_model import get_hosted_vm_list

def get_host_config(host_id):
    
    host_info = db.host[host_id]
    host_info.HDD = str(host_info.HDD) + ' GB'
    host_info.RAM = str(host_info.RAM) + ' GB'
    host_info.CPUs = str(host_info.CPUs) + ' CPU'

    return host_info

def get_host_util_data(util_period):
    hosts = db(db.host.status == HOST_STATUS_UP).select()
    host_util_dict = {}
    for host_info in hosts:
        host_identity = str(host_info.host_ip).replace('.','_')
        util_result = fetch_rrd_data(host_identity, int(util_period))
        total_mem_kb = host_info.RAM * GIGABYTE
        
        mem_util=(util_result[0]/float(total_mem_kb))*100

        element = {'Memory' : str(round(mem_util,2)) + "%",
                   'CPU'    : str(round(util_result[1],2)) + "%"}
        
        host_util_dict[host_info.id] = element

    return host_util_dict

def delete_host_from_db(host_id):
    
    host_data = db.host[host_id]
    private_ip_data = db.private_ip_pool(private_ip = host_data.host_ip)    
    if private_ip_data:
        remove_dhcp_entry(host_data.host_name, host_data.mac_addr, private_ip_data['private_ip'])
    db(db.scheduler_task.uuid == (UUID_VM_UTIL_RRD + "=" + str(host_data.host_ip))).delete()
    del db.host[host_id]

def update_host_status(host_id, status):
    host_data = db.host[host_id]
    logger.debug(host_data.host_ip)
    host_info=host_data.host_type
    logger.debug(host_info)
    if status == HOST_STATUS_UP:
        if is_host_available(host_data.host_ip):
                if host_data.CPUs == 0:
                    cpu_num = get_host_cpu(host_data.host_ip)
                    ram_gb = get_host_ram(host_data.host_ip)
                    hdd_gb = get_host_hdd(host_data.host_ip)
                    host_data.update_record(CPUs=cpu_num, RAM=ram_gb, HDD=hdd_gb)
        else:   
            host_power_up(host_data)                

        host_data.update_record(status = HOST_STATUS_UP)

    elif status == HOST_STATUS_MAINTENANCE:
        migrate_all_vms_from_host(host_data.host_ip)
        host_data.update_record(status=HOST_STATUS_MAINTENANCE)

    elif status == HOST_STATUS_DOWN:
        host_power_down(host_data)          
        host_data.update_record(status = HOST_STATUS_DOWN )  

    return True

def get_host_form(host_ip):
    
    form = get_add_host_form()
    form.vars.host_name = 'host'+str(host_ip.split('.')[3])
    form.vars.host_ip = host_ip
    if is_host_available(host_ip):
        form.vars.mac_addr = get_host_mac_address(host_ip)
        form.vars.CPUs = get_host_cpu(host_ip)
        form.vars.RAM  = get_host_ram(host_ip)
        form.vars.HDD = get_host_hdd(host_ip)
        form.vars.host_type = get_host_type(host_ip)
        form.vars.status = HOST_STATUS_UP
    else:
        form.vars.status = HOST_STATUS_DOWN

    return form
    

def configure_host_by_mac(mac_addr):
    
    avl_private_ip = None
    ip_info = db.private_ip_pool(mac_addr=mac_addr)
    if ip_info:
        avl_private_ip = ip_info.private_ip
    else:
        avl_ip = db((~db.private_ip_pool.private_ip.belongs(db()._select(db.host.host_ip)))
                    & (db.private_ip_pool.vlan == HOST_VLAN_ID)).select(db.private_ip_pool.private_ip)
        if avl_ip.first():
            avl_private_ip = avl_ip.first()['private_ip']

    if avl_private_ip:
        logger.debug('Available IP for mac address %s is %s'%(mac_addr, avl_private_ip))
        host_name = 'host'+str(avl_private_ip.split('.')[3])
        create_dhcp_entry(host_name, mac_addr, avl_private_ip)
        db.host[0] = dict(host_ip=avl_private_ip, 
                          host_name=host_name, 
                          mac_addr=mac_addr, 
                          status=HOST_STATUS_DOWN)
        return 'Host configured. Proceed for PXE boot.'
    else:
        logger.error('Available Private IPs for host are exhausted.')
        return 'Available Private IPs for host are exhausted.'

def get_configure_host_form():
    form = FORM('Host MAC:',
                INPUT(_name = 'host_mac_addr', _id='host_mac_id', requires = [
                                IS_MAC_ADDRESS(),
                                IS_NOT_IN_DB(db, 'host.mac_addr', error_message='Host MAC is already configured')]),
                INPUT(_type = 'button', _value = 'Configure', _class = 'btn-submit'))
    return form


def get_add_host_form():
    form_fields = ['host_ip','host_name','mac_addr','HDD','RAM','CPUs', 'host_type']
    form_labels = {'host_ip':'Host IP','host_name':'Host Name','mac_addr':'MAC Address','HDD':'Harddisk(GB)','RAM':'RAM size in GB:','CPUs':'No. of CPUs:'}

    form = SQLFORM(db.host, fields = form_fields, labels = form_labels, submit_button = 'Add Host')
    return form

def get_search_host_form():
    form = FORM('Host IP :',
                INPUT(_name = 'host_ip', _id='host_ip_id', requires = [
                                IS_IPV4(error_message=IP_ERROR_MESSAGE),
                                IS_NOT_IN_DB(db, 'host.host_ip', error_message='Host IP is already configured')]),
                INPUT(_type = 'button', _value = 'Get Details', _class = 'btn-submit'))
    return form

def get_all_hosts() :
    
    hosts = db().select(db.host.ALL) 
    results = []
    for host in hosts:
        results.append({'ip'    :host.host_ip, 
                        'id'    :host.id, 
                        'name'  :host.host_name, 
                        'status':host.status, 
                        'RAM'   :host.RAM,
                        'CPUs'  :host.CPUs})    
    return results

def get_all_vm_ofhost(hostid):
    vms = db((db.vm_data.status.belongs(VM_STATUS_RUNNING, VM_STATUS_SUSPENDED, VM_STATUS_SHUTDOWN)) 
             & (db.vm_data.host_id == hostid )).select()
    return get_hosted_vm_list(vms)
