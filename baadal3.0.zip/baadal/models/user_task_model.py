# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta

from applications.baadal.models.common_task_model import get_task_list
from applications.baadal.models.mail_handler import send_email_to_approver


def get_my_task_list(task_status, task_num):
    
    task_query = db((db.task_queue_event.status.belongs(task_status)) 
                    & ((db.task_queue_event.vm_id.belongs(
                            db(auth.user.id == db.user_vm_map.user_id)._select(db.user_vm_map.vm_id))) 
                     | (db.task_queue_event.requester_id == auth.user.id)))
    events = task_query.select(db.task_queue_event.ALL, distinct=True, orderby = ~db.task_queue_event.start_time, limitby=(0,task_num))

    return get_task_list(events)
