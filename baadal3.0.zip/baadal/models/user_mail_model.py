# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta

from applications.baadal.models.common_task_model import get_task_list
from applications.baadal.models.mail_handler import send_email_to_approver


def get_mail_admin_form():
    form = FORM(TABLE(TR('Type:'),
                TR(TABLE(TR(TD(INPUT(_name='email_type', _type='radio', _value='report_bug', value='report_bug')),TD('Report Bug'),
                TD(INPUT(_name='email_type', _type='radio', _value='request')),TD('Log Request'),
                TD(INPUT(_name='email_type', _type='radio', _value='complaint')),TD('Lodge Complaint')))),TR('Subject:'),
                TR(TEXTAREA(_name='email_subject',_style='height:50px; width:100%', _cols='30', _rows='20',requires=IS_NOT_EMPTY())),TR('Message:'),
                TR(TEXTAREA(_name='email_message',_style='height:100px; width:100%', _cols='30', _rows='20',requires=IS_NOT_EMPTY())),
                
                TR(INPUT(_type = 'submit', _value = 'Send Email')),_style='width:100%; border:0px'))
    return form


def send_remind_faculty_email(req_id):
    req_data = db.request_queue[req_id]
    send_email_to_approver(req_data.owner_id, req_data.requester_id, req_data.request_type, req_data.request_time)


def send_remind_orgadmin_email(req_id):
    req_data = db.request_queue[req_id]
    admins = db((db.user.organisation_id == req_data.requester_id.organisation_id) 
                & (db.user.id == db.user_membership.user_id) 
                & (db.user_membership.group_id == db.user_group.id) 
                & (db.user_group.role == ORGADMIN)).select(db.user.id)
                
    for admin in admins:
        send_email_to_approver(admin.id, req_data.requester_id, req_data.request_type, req_data.request_time)
