# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta
from applications.baadal.models.common_request_model import get_pending_request_list
from applications.baadal.models.common_model import *


REQ_STATUS_REQUESTED = 1
REQ_STATUS_REJECTED  = 2
REQ_STATUS_VERIFIED  = 3
REQ_STATUS_APPROVED  = 4
REQ_STATUS_IN_QUEUE  = 5
REQ_STATUS_FAILED    =-1


def get_my_requests():

    requests = db(db.request_queue.requester_id==auth.user.id).select(db.request_queue.ALL)
    return get_pending_request_list(requests)

def is_request_in_queue(vm_id, task_type, snapshot_id=None):

    #Check if request is present in task_queue table
    _data =  db((db.task_queue.vm_id == vm_id) & (db.task_queue.task_type == task_type) 
                   & db.task_queue.status.belongs(TASK_QUEUE_STATUS_PENDING, TASK_QUEUE_STATUS_PROCESSING)).select()

    if _data:
        if snapshot_id != None:
            for req_data in _data:    
                params = req_data.parameters
                if params['snapshot_id'] == snapshot_id:
                    return True
        else:
            return True
    else:
        #Check if request is present in request_queue table
        _request = db((db.request_queue.parent_id == vm_id) & (db.request_queue.request_type == task_type) 
                   & db.request_queue.status.belongs(REQ_STATUS_REQUESTED, REQ_STATUS_VERIFIED, REQ_STATUS_APPROVED)).select()

        return True if _request else False


def get_request_status():
    status = REQ_STATUS_REQUESTED
    if (is_moderator() or is_orgadmin()):
        status = REQ_STATUS_APPROVED
    elif is_faculty():
        status = REQ_STATUS_VERIFIED

    return status

