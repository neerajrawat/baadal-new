# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta


#Create configuration dropdowns
def get_configuration_elem(form):
    
    templates = db().select(db.template.ALL)
    _label = LABEL(SPAN('Configuration:', ' ', SPAN('*', _class='fld_required'), ' '))

    for template in templates:
        _id = template.id
        select = SELECT(_name='configuration_'+str(_id))
        
        for _config in VM_CONFIGURATION:
            display = str(_config[0]) + ' CPU, ' + str(_config[1]) + 'GB RAM, ' + str(template.hdd) + 'GB HDD'
            value = str(_config[0]) + ',' + str(_config[1]) + ',' + str(template.hdd)
            select.insert(len(select), OPTION(display, _value=value))
            
        #Create TR tag, and insert label and select box
        config_elem = TR(_label,select,TD(),_id='config_row__'+str(_id))
        form[0].insert(2,config_elem)#insert tr element in the form


# Gets CPU, RAM and HDD information on the basis of template selected.
def set_configuration_elem(form):

    configVal = form.vars.configuration_0 #Default configuration dropdown
    template = form.vars.template_id
    
    # if configuration specific to selected template is available
    if eval('form.vars.configuration_'+str(template)) != None:
        configVal = eval('form.vars.configuration_'+str(template))

    configVal = configVal.split(',')
    
    form.vars.vCPU = int(configVal[0])
    form.vars.RAM = float(configVal[1])*1024
    form.vars.HDD = int(configVal[2])
    if form.vars.extra_HDD == None:
        form.vars.extra_HDD = 0

