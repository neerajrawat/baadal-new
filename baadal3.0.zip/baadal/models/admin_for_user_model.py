###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.network_helper import IS_MAC_ADDRESS, create_dhcp_entry, get_ips_in_range, generate_random_mac,\
    remove_dhcp_entry, create_dhcp_bulk_entry, is_valid_ipv4
from applications.baadal.modules.host_helper import is_host_available, get_host_mac_address, get_host_type
from applications.baadal.modules.host_vms import migrate_all_vms_from_host
from applications.baadal.modules.host_resource_details import get_host_cpu, get_host_ram, get_host_hdd, HOST_STATUS_UP, HOST_STATUS_DOWN, HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_power import host_power_up, host_power_down
from applications.baadal.modules.rrd_graph import fetch_rrd_data, VM_UTIL_24_HOURS, VM_UTIL_ONE_WEEK, VM_UTIL_ONE_MNTH, \
    VM_UTIL_ONE_YEAR, VM_UTIL_10_MINS
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_helper import launch_existing_vm_image, get_vm_image_location
from applications.baadal.modules.vm_disk import get_extra_disk_location
from applications.baadal.models.user_model import get_user_info, add_user_verify_row

def add_requester_user(form):

    add_user_verify_row(form, 
                        field_name = 'requester_user', 
                        field_label = 'VM Requester', 
                        verify_function = 'verify_requester()', 
                        row_id = 'requester_row',
                        is_required = True)

def add_owner_user(form):

    add_user_verify_row(form, 
                        field_name = 'owner_user', 
                        field_label = 'VM Owner', 
                        verify_function = 'verify_owner()', 
                        row_id = 'owner_row',
                        is_required = True)

def specify_user_roles(user_id, user_roles):
    message = None
    try:
        if not user_roles:
            message = "Only user role activated for user"
        else:
            for role in user_roles:
                db.user_membership.insert(user_id=user_id, group_id=role) 
            message = "User Activated with specified roles"
        db(db.user.id == user_id).update(registration_key='')    
        for row in db(db.user_group.role == USER).select(db.user_group.id):
                role_type_user = row.id
        db.user_membership.insert(user_id=user_id, group_id=role_type_user)
    except Exception:
        logger.debug("Ignoring duplicate role entry")
    return message
    

def disable_user(user_id):
    db(db.user.id == user_id).update(registration_key='disable')
    return "User disabled in DB"

def get_search_user_form():
    form = FORM('User ID:',
                INPUT(_name = 'user_id',requires = IS_NOT_EMPTY(), _id='add_user_id'),
                INPUT(_type = 'submit', _value = 'Verify'))
    return form
    

def get_user_form(username, vm_id):

    user_info = get_user_info(username, [USER,FACULTY,ORGADMIN, ADMIN])
    user_details = db.user[user_info[0]]
    
    form = FORM(TABLE(TR('Username:', INPUT(_name = 'username', _value = user_details.username, _readonly = True)), 
                      TR('First Name:', INPUT(_name = 'first_name',_value = user_details.first_name, _readonly = True)),
                      TR('Last Name:' , INPUT(_name = 'last_name',_value = user_details.last_name, _readonly = True)),
                      TR('Email ID:' , INPUT(_name = 'email',_value = user_details.email, _readonly = True)),
                      TR(INPUT(_type='button', _value = 'Cancel', _onclick = "window.location='%s';"%URL(r=request,c = 'user', f='settings', args = vm_id )),INPUT(_type = 'submit', _value = 'Confirm Details'))))

    form.vars.user_id = user_details.id
    form.vars.username = user_details.username
    form.vars.first_name = user_details.first_name
    form.vars.last_name = user_details.last_name
    form.vars.email = user_details.email

    return form


def get_all_unregistered_users():
    unregistered_users=db(db.user.registration_key == USER_PENDING_APPROVAL).select()
    return unregistered_users


def get_users_with_roles():
    all_users = db((db.user.registration_key == "") & (db.user.block_user == False)).select()
    for user in all_users:
        user['organisation'] = user.organisation_id.name
        roles=[]
        for membership in db(db.user_membership.user_id == user.id).select(db.user_membership.group_id):
            roles.extend([membership.group_id])
        user['roles'] = roles
    return all_users


def validate_user(form):
    username = request.post_vars.user_id
    user_info = get_user_info(username)

    if not user_info:
        form.errors.user_id = 'Username is not valid'
    else:
        vm_id = request.args[0]
        if db((db.user_vm_map.user_id == user_info[0]) 
              & (db.user_vm_map.vm_id == vm_id)).select():
            form.errors.user_id = 'User is an existing collaborator of VM'
    return form

