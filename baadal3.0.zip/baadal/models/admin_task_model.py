###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.network_helper import IS_MAC_ADDRESS, create_dhcp_entry, get_ips_in_range, generate_random_mac,\
    remove_dhcp_entry, create_dhcp_bulk_entry, is_valid_ipv4
from applications.baadal.modules.host_helper import is_host_available, get_host_mac_address, get_host_type
from applications.baadal.modules.host_vms import migrate_all_vms_from_host
from applications.baadal.modules.host_resource_details import get_host_cpu, get_host_ram, get_host_hdd, HOST_STATUS_UP, HOST_STATUS_DOWN, HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_power import host_power_up, host_power_down
from applications.baadal.modules.rrd_graph import fetch_rrd_data, VM_UTIL_24_HOURS, VM_UTIL_ONE_WEEK, VM_UTIL_ONE_MNTH, \
    VM_UTIL_ONE_YEAR, VM_UTIL_10_MINS
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_helper import launch_existing_vm_image, get_vm_image_location
from applications.baadal.modules.vm_disk import get_extra_disk_location
from applications.baadal.models.common_vm_model import add_vm_users, add_vm_task_to_queue
from applications.baadal.models.common_task_model import get_task_list
from applications.baadal.models.admin_vm_model import *


def create_clone_task(req_data, params):

    clone_count = req_data.clone_count
    vm_data = db.vm_data[req_data.parent_id]
    
    clone_name = req_data.vm_name
    cnt = 1;
    
    vm_id_list = []
    for count in range(0, clone_count):  # @UnusedVariable

        while(db.vm_data(vm_name=(clone_name+str(cnt)))):
            cnt = cnt+1

        clone_vm_name = clone_name + str(cnt)
        
        clone_vm_id = db.vm_data.insert(
                          vm_name = clone_vm_name, 
                          vm_identity = get_vm_identity(clone_vm_name, vm_data.owner_id), 
                          RAM = vm_data.RAM,
                          HDD = vm_data.HDD,
                          extra_HDD = vm_data.extra_HDD,
                          vCPU = vm_data.vCPU,
                          template_id = vm_data.template_id,
                          owner_id = vm_data.owner_id,
                          requester_id = req_data.requester_id,
                          parent_id = req_data.parent_id,
                          public_ip = PUBLIC_IP_NOT_ASSIGNED,
                          security_domain = vm_data.security_domain,
                          purpose = req_data.purpose,
                          status = VM_STATUS_IN_QUEUE)

        vm_id_list.append(clone_vm_id)
        
        vm_users=[]
        for user in db(db.user_vm_map.vm_id == vm_data.id).select(db.user_vm_map.user_id):
            vm_users.append(user['user_id'])

        add_vm_users(clone_vm_id, vm_data.requester_id, vm_data.owner_id, vm_users=vm_users)
        cnt = cnt+1
        
    params.update({'clone_vm_id':vm_id_list})
    add_vm_task_to_queue(req_data.parent_id, TASK_TYPE_CLONE_VM, params=params, requested_by=req_data.requester_id)

def create_install_task(req_data, params):

    vm_id = db.vm_data.insert(
                  vm_name = req_data.vm_name, 
                  vm_identity = get_vm_identity(req_data.vm_name, req_data.owner_id), 
                  RAM = req_data.RAM,
                  HDD = req_data.HDD,
                  extra_HDD = req_data.extra_HDD,
                  vCPU = req_data.vCPU,
                  template_id = req_data.template_id,
                  requester_id = req_data.requester_id,
                  owner_id = req_data.owner_id,
                  purpose = req_data.purpose,
                  public_ip = PUBLIC_IP_NOT_ASSIGNED if not(req_data.public_ip) else None,
                  security_domain = req_data.security_domain,
                  status = VM_STATUS_IN_QUEUE)
        
    add_vm_users(vm_id, req_data.requester_id, req_data.owner_id, req_data.collaborators)
    add_vm_task_to_queue(vm_id, TASK_TYPE_CREATE_VM, params=params, requested_by=req_data.requester_id)

def create_edit_config_task(req_data, params):
    
    vm_data = db.vm_data[req_data.parent_id]
    
    if vm_data.RAM != req_data.RAM : params['ram'] = req_data.RAM
    if vm_data.vCPU != req_data.vCPU : params['vcpus'] = req_data.vCPU
    if (vm_data.public_ip != PUBLIC_IP_NOT_ASSIGNED) ^ req_data.public_ip:
        params['public_ip'] = req_data.public_ip
    
    if vm_data.security_domain != req_data.security_domain : params['security_domain'] = req_data.security_domain

    add_vm_task_to_queue(req_data.parent_id, req_data.request_type, params=params)



def get_task_by_status(task_status, task_num):
    events = db(db.task_queue_event.status.belongs(task_status)).select(orderby = ~db.task_queue_event.start_time, limitby=(0,task_num))
    return get_task_list(events)
    

def update_task_retry(event_id):

    task_event_data = db.task_queue_event[event_id]
    task_queue_data = db.task_queue[task_event_data.task_id]
    
    if 'request_id' in task_queue_data.parameters:
        #Mark status for request as 'In Queue'
        request_id = task_queue_data.parameters['request_id']
        if db.request_queue[request_id]:
            db.request_queue[request_id] = dict(status=REQ_STATUS_IN_QUEUE)
    
    if task_event_data.task_type == TASK_TYPE_CREATE_VM:
        db.vm_data[task_event_data.vm_id] = dict(status=VM_STATUS_IN_QUEUE)
    elif task_event_data.task_type == TASK_TYPE_CLONE_VM:
        vm_list = task_queue_data.parameters['clone_vm_id']
        for vm in vm_list:
            db.vm_data[vm] = dict(status=VM_STATUS_IN_QUEUE)

    #Mark current task event for the task as IGNORE. 
    task_event_data.update_record(status=TASK_QUEUE_STATUS_RETRY)
    #Mark task as RETRY. This will call task_queue_update_callback; which will schedule a new task
    task_queue_data.update_record(status=TASK_QUEUE_STATUS_RETRY)


def update_task_ignore(event_id):

    task_event_data = db.task_queue_event[event_id]
    task_queue_data = db.task_queue[task_event_data.task_id]

    if 'request_id' in task_event_data.parameters:
        request_id = task_event_data.parameters['request_id']
        if db.request_queue[request_id]:
            del db.request_queue[request_id]
    
    if task_event_data.task_type == TASK_TYPE_CREATE_VM:
        if db.vm_data[task_event_data.vm_id]: del db.vm_data[task_event_data.vm_id]
    elif task_event_data.task_type == TASK_TYPE_CLONE_VM:
        vm_list = task_event_data.parameters['clone_vm_id']
        for vm in vm_list:
            if db.vm_data[vm]: del db.vm_data[vm]

    task_event_data.update_record(task_id = None, status=TASK_QUEUE_STATUS_IGNORE)

    #Delete task from task_queue
    if task_queue_data:
        if db.task_queue[task_queue_data.id]:
            del db.task_queue[task_queue_data.id]


def create_clone_task(req_data, params):

    clone_count = req_data.clone_count
    vm_data = db.vm_data[req_data.parent_id]
    
    clone_name = req_data.vm_name
    cnt = 1;
    
    vm_id_list = []
    for count in range(0, clone_count):  # @UnusedVariable

        while(db.vm_data(vm_name=(clone_name+str(cnt)))):
            cnt = cnt+1

        clone_vm_name = clone_name + str(cnt)
        
        clone_vm_id = db.vm_data.insert(
                          vm_name = clone_vm_name, 
                          vm_identity = get_vm_identity(clone_vm_name, vm_data.owner_id), 
                          RAM = vm_data.RAM,
                          HDD = vm_data.HDD,
                          extra_HDD = vm_data.extra_HDD,
                          vCPU = vm_data.vCPU,
                          template_id = vm_data.template_id,
                          owner_id = vm_data.owner_id,
                          requester_id = req_data.requester_id,
                          parent_id = req_data.parent_id,
                          public_ip = PUBLIC_IP_NOT_ASSIGNED,
                          security_domain = vm_data.security_domain,
                          purpose = req_data.purpose,
                          status = VM_STATUS_IN_QUEUE)

        vm_id_list.append(clone_vm_id)
        
        vm_users=[]
        for user in db(db.user_vm_map.vm_id == vm_data.id).select(db.user_vm_map.user_id):
            vm_users.append(user['user_id'])

        add_vm_users(clone_vm_id, vm_data.requester_id, vm_data.owner_id, vm_users=vm_users)
        cnt = cnt+1
        
    params.update({'clone_vm_id':vm_id_list})
    add_vm_task_to_queue(req_data.parent_id, TASK_TYPE_CLONE_VM, params=params, requested_by=req_data.requester_id)

def create_install_task(req_data, params):

    vm_id = db.vm_data.insert(
                  vm_name = req_data.vm_name, 
                  vm_identity = get_vm_identity(req_data.vm_name, req_data.owner_id), 
                  RAM = req_data.RAM,
                  HDD = req_data.HDD,
                  extra_HDD = req_data.extra_HDD,
                  vCPU = req_data.vCPU,
                  template_id = req_data.template_id,
                  requester_id = req_data.requester_id,
                  owner_id = req_data.owner_id,
                  purpose = req_data.purpose,
                  public_ip = PUBLIC_IP_NOT_ASSIGNED if not(req_data.public_ip) else None,
                  security_domain = req_data.security_domain,
                  status = VM_STATUS_IN_QUEUE)
        
    add_vm_users(vm_id, req_data.requester_id, req_data.owner_id, req_data.collaborators)
    add_vm_task_to_queue(vm_id, TASK_TYPE_CREATE_VM, params=params, requested_by=req_data.requester_id)

def create_edit_config_task(req_data, params):
    
    vm_data = db.vm_data[req_data.parent_id]
    
    if vm_data.RAM != req_data.RAM : params['ram'] = req_data.RAM
    if vm_data.vCPU != req_data.vCPU : params['vcpus'] = req_data.vCPU
    if (vm_data.public_ip != PUBLIC_IP_NOT_ASSIGNED) ^ req_data.public_ip:
        params['public_ip'] = req_data.public_ip
    
    if vm_data.security_domain != req_data.security_domain : params['security_domain'] = req_data.security_domain

    add_vm_task_to_queue(req_data.parent_id, req_data.request_type, params=params)



def get_task_by_status(task_status, task_num):
    events = db(db.task_queue_event.status.belongs(task_status)).select(orderby = ~db.task_queue_event.start_time, limitby=(0,task_num))
    return get_task_list(events)
    

def update_task_retry(event_id):

    task_event_data = db.task_queue_event[event_id]
    task_queue_data = db.task_queue[task_event_data.task_id]
    
    if 'request_id' in task_queue_data.parameters:
        #Mark status for request as 'In Queue'
        request_id = task_queue_data.parameters['request_id']
        if db.request_queue[request_id]:
            db.request_queue[request_id] = dict(status=REQ_STATUS_IN_QUEUE)
    
    if task_event_data.task_type == TASK_TYPE_CREATE_VM:
        db.vm_data[task_event_data.vm_id] = dict(status=VM_STATUS_IN_QUEUE)
    elif task_event_data.task_type == TASK_TYPE_CLONE_VM:
        vm_list = task_queue_data.parameters['clone_vm_id']
        for vm in vm_list:
            db.vm_data[vm] = dict(status=VM_STATUS_IN_QUEUE)

    #Mark current task event for the task as IGNORE. 
    task_event_data.update_record(status=TASK_QUEUE_STATUS_RETRY)
    #Mark task as RETRY. This will call task_queue_update_callback; which will schedule a new task
    task_queue_data.update_record(status=TASK_QUEUE_STATUS_RETRY)


def update_task_ignore(event_id):

    task_event_data = db.task_queue_event[event_id]
    task_queue_data = db.task_queue[task_event_data.task_id]

    if 'request_id' in task_event_data.parameters:
        request_id = task_event_data.parameters['request_id']
        if db.request_queue[request_id]:
            del db.request_queue[request_id]
    
    if task_event_data.task_type == TASK_TYPE_CREATE_VM:
        if db.vm_data[task_event_data.vm_id]: del db.vm_data[task_event_data.vm_id]
    elif task_event_data.task_type == TASK_TYPE_CLONE_VM:
        vm_list = task_event_data.parameters['clone_vm_id']
        for vm in vm_list:
            if db.vm_data[vm]: del db.vm_data[vm]

    task_event_data.update_record(task_id = None, status=TASK_QUEUE_STATUS_IGNORE)

    #Delete task from task_queue
    if task_queue_data:
        if db.task_queue[task_queue_data.id]:
            del db.task_queue[task_queue_data.id]


