# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta
from applications.baadal.models.common_host_model import get_hosted_vm_list
from applications.baadal.models.user_configuration_model import *
from applications.baadal.models.user_request_model import get_request_status
from applications.baadal.models.common_vm_model import is_vm_user, get_vm_info, get_vm_status
from applications.baadal.models.user_approver_collaborator_model import *
from applications.baadal.models.common_model import *


def get_my_hosted_vm():
    vms = db((~db.vm_data.status.belongs(VM_STATUS_IN_QUEUE, VM_STATUS_UNKNOWN)) 
             & (db.vm_data.id==db.user_vm_map.vm_id) 
             & (db.user_vm_map.user_id==auth.user.id)).select(db.vm_data.ALL)

    return get_hosted_vm_list(vms)

def is_vm_name_unique(user_set, vm_name=None, vm_id=None):
    
    if vm_id != None:
        vm_data = db.vm_data[vm_id]
        vm_name = vm_data.vm_name
        
    vms = db((db.vm_data.id == db.user_vm_map.vm_id) & 
             (db.user_vm_map.user_id.belongs(user_set)) & 
             (db.vm_data.vm_name.like(vm_name))).select()
    
    if vms:
        return False

    requests = db(((db.request_queue.owner_id.belongs(user_set)) |
                   (db.request_queue.requester_id.belongs(user_set))) & 
                   (db.request_queue.vm_name.like(vm_name))).select()
    
    if requests:
        return False

    return True

    
def request_vm_validation(form):
    
    set_configuration_elem(form)
    form.vars.status = get_request_status()

    if is_vm_user():
        validate_approver(form)
    else:
        form.vars.owner_id = auth.user.id

    vm_users = request.post_vars.vm_users
    user_list = []
    if vm_users and len(vm_users) > 1:
        for vm_user in vm_users[1:-1].split('|'):
            user_list.append(db(db.user.username == vm_user).select(db.user.id).first()['id'])
    
    if request.post_vars.faculty_user:
        user_list.append(form.vars.owner_id)
    form.vars.collaborators = user_list

    user_set = set(user_list)
    user_set.add(auth.user.id)

    if not is_vm_name_unique(user_set, form.vars.vm_name):
        form.errors.vm_name = 'VM name should be unique for the user. Choose another name.'



def get_request_vm_form():
    
    form_fields = ['vm_name','template_id','extra_HDD','purpose', 'security_domain', 'public_ip']

    db.request_queue.request_type.default = TASK_TYPE_CREATE_VM
    db.request_queue.requester_id.default = auth.user.id
    _query = (db.security_domain.visible_to_all == True) | (db.security_domain.org_visibility.contains(auth.user.organisation_id))
    db.request_queue.security_domain.requires = IS_IN_DB(db(_query), 'security_domain.id', '%(name)s', zero=None)
    db.request_queue.security_domain.default = 2
    db.request_queue.security_domain.notnull = True
    db.request_queue.template_id.notnull = True

    mark_required(db.request_queue)
    form =SQLFORM(db.request_queue, fields = form_fields, hidden=dict(vm_users='|'))
    get_configuration_elem(form) # Create dropdowns for configuration
    
    if is_vm_user(): add_faculty_approver(form)
    
    add_collaborators(form)
    return form


def get_vm_config(vm_id):

    vminfo = get_vm_info(vm_id)
    if not vminfo : return
    
    vm_info_map = {'id'               : str(vminfo.vm_data.id),
                   'name'             : str(vminfo.vm_data.vm_name),
                   'hdd'              : str(vminfo.vm_data.HDD)+' GB' + ('+ ' + str(vminfo.vm_data.extra_HDD) + ' GB' if vminfo.vm_data.extra_HDD!=0 else ''),
                   'ram'              : str(vminfo.vm_data.RAM) + ' MB',
                   'vcpus'            : str(vminfo.vm_data.vCPU) + ' CPU',
                   'status'           : get_vm_status(vminfo.vm_data.status),
                   'os_type'          : str(vminfo.template.os_name) + ' ' + str(vminfo.template.os_version) + ' ' + str(vminfo.template.os_type) + ' ' + str(vminfo.template.arch),
                   'purpose'          : str(vminfo.vm_data.purpose),
                   'private_ip'       : str(vminfo.vm_data.private_ip),
                   'public_ip'        : str(vminfo.vm_data.public_ip),
                   'snapshot_flag'    : int(vminfo.vm_data.snapshot_flag),
                   'security_domain'  : str(vminfo.vm_data.security_domain.name)}

    if is_moderator():
        vm_info_map.update({'host' : str(vminfo.vm_data.host_id.host_ip)})
    
    vnc_info = db((db.vnc_access.vm_id == vm_id) & (db.vnc_access.status == VNC_ACCESS_STATUS_ACTIVE)).select()
    if vnc_info:
        vm_info_map.update({'vnc_ip' : str(vnc_info[0].vnc_server_ip), 'vnc_port' : str(vnc_info[0].vnc_source_port)})

    return vm_info_map  
    
    
def get_vm_user_list(vm_id) :		
    vm_users = db((vm_id == db.user_vm_map.vm_id) & (db.user_vm_map.user_id == db.user.id)).select(db.user.ALL)
    user_id_lst = []
    for vm_user in vm_users:
        user_id_lst.append(vm_user)
    return user_id_lst


def check_snapshot_limit(vm_id):
    snapshots = db((db.snapshot.vm_id == vm_id) & (db.snapshot.type == SNAPSHOT_USER)).count()
    logger.debug("No of snapshots are " + str(snapshots))
    if snapshots < SNAPSHOTTING_LIMIT:
        return True
    else:
        return False

def get_clone_vm_form(vm_id):
    vm_data = db.vm_data[vm_id]
    
    clone_name = vm_data.vm_name + '_clone'
    cnt = 1;
    while(db.request_queue(vm_name=(clone_name+str(cnt)))):
        cnt = cnt+1
    
    db.request_queue.parent_id.default = vm_data.id
    db.request_queue.vm_name.default = clone_name + str(cnt)
    db.request_queue.HDD.default = vm_data.HDD
    db.request_queue.RAM.default = vm_data.RAM
    db.request_queue.vCPU.default = vm_data.vCPU
    db.request_queue.request_type.default = TASK_TYPE_CLONE_VM
    db.request_queue.status.default = get_request_status()
    db.request_queue.requester_id.default = auth.user.id
    db.request_queue.owner_id.default = vm_data.owner_id
    db.request_queue.security_domain.default = vm_data.security_domain
    db.request_queue.clone_count.requires = IS_INT_IN_RANGE(1,101)
    db.request_queue.vm_name.writable = False
    form_fields = ['vm_name', 'clone_count', 'purpose']
    
    form =SQLFORM(db.request_queue, fields = form_fields)
    return form    

def get_edit_vm_config_form(vm_id):
    
    vm_data = db.vm_data[vm_id]
    db.request_queue.parent_id.default = vm_data.id
    db.request_queue.vm_name.default = vm_data.vm_name
    db.request_queue.RAM.default = vm_data.RAM
    db.request_queue.RAM.requires = IS_IN_SET(VM_RAM_SET, zero=None)
    db.request_queue.vCPU.default = vm_data.vCPU
    db.request_queue.vCPU.requires = IS_IN_SET(VM_vCPU_SET, zero=None)
    db.request_queue.HDD.default = vm_data.HDD
    db.request_queue.public_ip.default = (vm_data.public_ip != PUBLIC_IP_NOT_ASSIGNED)
    db.request_queue.security_domain.default = vm_data.security_domain
    db.request_queue.request_type.default = TASK_TYPE_EDITCONFIG_VM
    db.request_queue.status.default = get_request_status()
    db.request_queue.requester_id.default = auth.user.id
    db.request_queue.owner_id.default = vm_data.owner_id
    _query = (db.security_domain.visible_to_all == True) | (db.security_domain.org_visibility.contains(vm_data.requester_id.organisation_id))
    db.request_queue.security_domain.requires = IS_IN_DB(db(_query), 'security_domain.id', '%(name)s', zero=None)
    
    form_fields = ['vm_name', 'RAM', 'vCPU', 'public_ip', 'security_domain','purpose']
    form = SQLFORM(db.request_queue, fields = form_fields)

    return form

def edit_vm_config_validation(form):
    
    vm_id = request.args[0]
    vm_data = db.vm_data[vm_id]
    
    curr_public_ip = False if vm_data.public_ip == PUBLIC_IP_NOT_ASSIGNED else True
    new_public_ip = True if form.vars.public_ip else False
    
    if ((long(form.vars.vCPU) == long(vm_data.vCPU)) & 
        (long(form.vars.security_domain) == long(vm_data.security_domain)) & 
        (long(form.vars.RAM) == long(vm_data.RAM)) & 
        (new_public_ip == curr_public_ip)):
        
        form.errors.vCPU = 'No change in VM properties.'

def get_vm_history(vm_id):
    
    vm_history = []
    for vm_log in db(db.vm_event_log.vm_id == vm_id).select(orderby = ~db.vm_event_log.timestamp):
        element = {'attribute' : vm_log.attribute,
                   'old_value' : vm_log.old_value,
                   'new_value' : vm_log.new_value,
                   'requested_by' : vm_log.requester_id.first_name + ' ' + vm_log.requester_id.last_name if vm_log.requester_id > 0 else 'System User', 
                   'timestamp' : vm_log.timestamp}
        vm_history.append(element)
    return vm_history

def update_snapshot_flag(vm_id, flag):
    vm_data = db.vm_data[vm_id]
    vm_data.update_record(snapshot_flag=int(flag))


