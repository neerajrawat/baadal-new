# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    import gluon
    global auth; auth = gluon.tools.Auth()
    from gluon import db, request, session
    from gluon import *  # @UnusedWildImport
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.helper import log_exception, logger


def get_users_with_organisation(pending_users):
    users_with_org=[]
    for user in pending_users:
        user['organisation']=user.organisation_id.name
        users_with_org.append(user)
    return users_with_org
        
def get_user_role_types():
    user_types=db(db.user_group.role != USER).select(db.user_group.id, db.user_group.role);
    return user_types
        
def delete_all_user_roles(user_id):
    db(db.user_membership.user_id == user_id).delete()        
        

# Get user name and email
def get_user_details(user_id):
    if user_id < 0:
            return ('System User',None, None)
    else:
        user = db.user[user_id]
        if user :
            username = user.first_name + ' ' + user.last_name
            email = user.email if user.mail_subscribed else None
 
            return (username, email, user.username)
        else:
            return (None, None, None)


def get_full_name(user_id):
    return get_user_details(user_id)[0]
