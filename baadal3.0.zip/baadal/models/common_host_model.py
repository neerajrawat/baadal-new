# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    import gluon
    global auth; auth = gluon.tools.Auth()
    from gluon import db, request, session
    from gluon import *  # @UnusedWildImport
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.helper import log_exception, logger
from applications.baadal.models.common_vm_model import get_vm_status

def get_hosted_vm_list(vms):
    vmlist = []
    for vm in vms:
        element = {'id' : vm.id,
                   'name' : vm.vm_name,
                   'organisation' : vm.owner_id.organisation_id.name if vm.owner_id > 0 else 'System',
                   'owner' : vm.owner_id.first_name + ' ' + vm.owner_id.last_name if vm.owner_id > 0 else 'System User', 
                   'private_ip' : vm.private_ip, 
                   'public_ip' : vm.public_ip, 
                   'hostip' : vm.host_id.host_ip,
                   'RAM' : str(round((vm.RAM/1024.0),2)) + ' GB',
                   'vcpus' : str(vm.vCPU) + ' CPU',
                   'status' : get_vm_status(vm.status)}
        vmlist.append(element)
    return vmlist

