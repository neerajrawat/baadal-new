# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    import gluon
    global auth; auth = gluon.tools.Auth()
    from gluon import db, request, session
    from gluon import *  # @UnusedWildImport
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################


from applications.baadal.modules.helper import log_exception, logger
from applications.baadal.models.common_vm_model import *
from applications.baadal.models.common_usercheck_model import *
from gluon.tools import redirect

ADMIN = 'admin'
ORGADMIN = 'orgadmin'
FACULTY = 'faculty'
USER = 'user'

HTTP="http"

# Generic exception handler decorator
def handle_exception(fn):
    def decorator(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except HTTP:
            raise
        except:
            exception_handler()
    return decorator    


def exception_handler():
    msg = log_exception('Exception: ') 
    if is_moderator():
        error = msg
    else:
        error = 'Some error has occurred'
    redirect(URL(c='default', f='error',vars={'error':error}))    
    
    
# Generic check moderator decorator
def check_moderator(fn):
    def decorator(*args, **kwargs):
        if is_moderator():
            return fn(*args, **kwargs)
        else:
            session.flash = "You don't have admin privileges"
            redirect(URL(c='default', f='index'))
    return decorator    
   
    
# Generic check orgadmin decorator
def check_orgadmin(fn):
    def decorator(*args, **kwargs):
        if (is_moderator() or is_orgadmin()):
            return fn(*args, **kwargs)
        else:
            session.flash = "You don't have org admin privileges"
            redirect(URL(c='default', f='index'))
    return decorator    


# Generic check faculty decorator
def check_faculty(fn):
    def decorator(*args, **kwargs):
        if not is_vm_user():
            return fn(*args, **kwargs)
        else:
            session.flash = "You don't have faculty privileges"
            redirect(URL(c='default', f='index'))
    return decorator    


def get_faculty_info(faculty_id):
    faculty_info = db(db.user.id==faculty_id).select()
    if not faculty_info:
        return None
    return faculty_info.first()


def mark_required(table):
    
    marker = SPAN('*', _class='fld_required')
    for field in table:
        required = False
        if field.notnull:
            required = True
        elif field.requires:
            required=isinstance(field.requires,(IS_IN_SET, IS_IPV4))
        if required:
            _label = field.label
            field.label = SPAN(_label, ' ', marker, ' ')
