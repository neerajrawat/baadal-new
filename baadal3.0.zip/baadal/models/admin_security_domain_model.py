###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.network_helper import IS_MAC_ADDRESS, create_dhcp_entry, get_ips_in_range, generate_random_mac,\
    remove_dhcp_entry, create_dhcp_bulk_entry, is_valid_ipv4
from applications.baadal.modules.host_helper import is_host_available, get_host_mac_address, get_host_type
from applications.baadal.modules.host_vms import migrate_all_vms_from_host
from applications.baadal.modules.host_resource_details import get_host_cpu, get_host_ram, get_host_hdd, HOST_STATUS_UP, HOST_STATUS_DOWN, HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_power import host_power_up, host_power_down
from applications.baadal.modules.rrd_graph import fetch_rrd_data, VM_UTIL_24_HOURS, VM_UTIL_ONE_WEEK, VM_UTIL_ONE_MNTH, \
    VM_UTIL_ONE_YEAR, VM_UTIL_10_MINS
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_helper import launch_existing_vm_image, get_vm_image_location
from applications.baadal.modules.vm_disk import get_extra_disk_location



def get_security_domain_form():
    
    db.security_domain.id.readable=False 

    fields = (db.security_domain.name, db.security_domain.vlan)
    default_sort_order=[db.security_domain.id]
    
    create = True
    avl_vlan = db(~db.vlan.id.belongs(db()._select(db.security_domain.vlan))).count()
    if avl_vlan == 0: create = False

    form = SQLFORM.grid(db.security_domain, fields=fields, orderby=default_sort_order, paginate=ITEMS_PER_PAGE, create=create, 
                        csv=False, searchable=False, details=False, selectable=False, showbuttontext=False, maxtextlength=30, 
                        links=[dict(header='Visibility', body=get_org_visibility)])
    return form

# Check if the security domain can be deleted
def check_delete_security_domain(sd_id):
    if db.vm_data(security_domain = sd_id):
        return SECURITY_DOMAIN_DELETE_MESSAGE
    elif db.security_domain[sd_id].name in ('Research', 'Private', 'Infrastructure'):
        return 'Security Domain %s can''t be deleted.' %(db.security_domain[sd_id].name)

