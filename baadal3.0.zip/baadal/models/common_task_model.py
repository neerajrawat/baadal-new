# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    import gluon
    global auth; auth = gluon.tools.Auth()
    from gluon import db, request, session
    from gluon import *  # @UnusedWildImport
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.helper import log_exception, logger
from applications.baadal.models.common_user_model import get_full_name


def get_task_list(events):

    tasks = []
    for event in events:
        element = {'event_id'  :event.id,
                   'task_type' :event.task_type,
                   'task_id'   :event.task_id,
                   'vm_name'   :event.vm_name,
                   'user_name' :get_full_name(event.requester_id),
                   'start_time':event.start_time,
                   'att_time'  :event.attention_time,
                   'end_time'  :event.end_time,
                   'error_msg' :event.message}
        tasks.append(element)
    return tasks

def get_task_num_form():
    form = FORM('Show:',
                INPUT(_name = 'task_num', _class='task_num', requires = IS_INT_IN_RANGE(1,101), _id='task_num_id'),
                A(SPAN(_class='icon-refresh'), _onclick = 'tab_refresh();$(this).closest(\'form\').submit()', _href='#'))
    return form

