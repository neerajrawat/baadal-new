###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db, request, session
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.modules.network_helper import IS_MAC_ADDRESS, create_dhcp_entry, get_ips_in_range, generate_random_mac,\
    remove_dhcp_entry, create_dhcp_bulk_entry, is_valid_ipv4
from applications.baadal.modules.host_helper import is_host_available, get_host_mac_address, get_host_type
from applications.baadal.modules.host_vms import migrate_all_vms_from_host
from applications.baadal.modules.host_resource_details import get_host_cpu, get_host_ram, get_host_hdd, HOST_STATUS_UP, HOST_STATUS_DOWN, HOST_STATUS_MAINTENANCE
from applications.baadal.modules.host_power import host_power_up, host_power_down
from applications.baadal.modules.rrd_graph import fetch_rrd_data, VM_UTIL_24_HOURS, VM_UTIL_ONE_WEEK, VM_UTIL_ONE_MNTH, \
    VM_UTIL_ONE_YEAR, VM_UTIL_10_MINS
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.vm_helper import launch_existing_vm_image, get_vm_image_location
from applications.baadal.modules.vm_disk import get_extra_disk_location
from applications.baadal.models.common_host_model import get_hosted_vm_list
from applications.baadal.models.admin_task_model import *
from applications.baadal.models.common_vm_model import add_vm_users, add_vm_task_to_queue
from applications.baadal.models.admin_host_model import get_all_hosts, get_all_vm_ofhost
from applications.baadal.models.admin_model import add_live_migration_option
from applications.baadal.models.admin_disk_model import add_extra_disk
from applications.baadal.models.admin_for_user_model import add_requester_user, add_owner_user
from applications.baadal.models.user_approver_collaborator_model import add_collaborators
from applications.baadal.models.user_model import get_user_info
from applications.baadal.models.admin_network_model import add_private_ip



def get_vm_link(row):
    if (row.vm_id == None) & (row.host_id==None):
        return 'Unassigned'
    elif row.vm_id != None:
        vm_data = db.vm_data[row.vm_id]
        return A(vm_data.vm_name, _href=URL(r=request, c='user',f='settings', args=vm_data.id))
    elif row.host_id != None:
        host_data = db.host[row.host_id]
        return A(host_data.host_name, _href=URL(r=request, c='admin',f='host_config', args=host_data.id))

def get_all_vm_list():
    vms = db(db.vm_data.status.belongs(VM_STATUS_RUNNING, VM_STATUS_SUSPENDED, VM_STATUS_SHUTDOWN)).select()
    return get_hosted_vm_list(vms)


def get_vm_identity(vm_name, owner_id):
    vm_owner = db.user[owner_id]
    
    vm_identity = '%s_%s_%s'%(vm_owner.organisation_id.name, vm_owner.username, vm_name)
    
    return vm_identity

def enqueue_vm_request(request_id):
    
    req_data = db.request_queue[request_id]
    params={'request_id' : request_id}
    
    if req_data.request_type == TASK_TYPE_CLONE_VM:
        create_clone_task(req_data, params)
    elif req_data.request_type == TASK_TYPE_CREATE_VM:
        create_install_task(req_data, params)
    elif req_data.request_type == TASK_TYPE_EDITCONFIG_VM:
        create_edit_config_task(req_data, params)
    elif req_data.request_type == TASK_TYPE_ATTACH_DISK:
        params.update({'disk_size' : req_data.attach_disk})
        add_vm_task_to_queue(req_data.parent_id, req_data.request_type, params=params, requested_by=req_data.requester_id)
    
    db(db.request_queue.id == request_id).update(status=REQ_STATUS_IN_QUEUE)


def delete_user_vm_access(vm_id, user_id) :

    vm_data = db.vm_data[vm_id]
    if vm_data.owner_id == user_id:
        vm_data.update_record(owner_id = -1)
    if vm_data.requester_id == user_id:
        vm_data.update_record(requester_id = -1)

    db((db.user_vm_map.vm_id == vm_id) & (db.user_vm_map.user_id == user_id)).delete()  


def add_user_vm_access(vm_id, user_id) :    
    db.user_vm_map.insert(vm_id = vm_id, user_id = user_id)       


def update_vm_lock(vminfo,flag) :
        db(db.vm_data.id == vminfo.id).update(locked = flag)


def get_vm_groupby_hosts() :
    hosts = get_all_hosts()              
    hostvmlist = []
    for host in hosts:    # for each host get all the vm's that runs on it and add them to list                          
        vmlist = get_all_vm_ofhost(host['id'])
        hostvms = {'host_id':host['id'],
                   'host_ip':host['ip'], 
                   'details':vmlist}
        hostvmlist.append(hostvms)    
    return (hostvmlist)

def get_migrate_vm_form(vm_id):

    form = None
    host_id = db(db.vm_data.id == vm_id).select(db.vm_data.host_id).first()['host_id']
    host_options = [OPTION(host.host_ip, _value = host.id) for host in db((db.host.id != host_id) & (db.host.status == 1)).select()]
    if host_options:
        form = FORM(TABLE(TR('VM Name:', INPUT(_name = 'vm_name', _readonly = True)), 
                      TR('Current Host:', INPUT(_name = 'current_host', _readonly = True)),
                      TR('Destination Host:' , SELECT(*host_options, **dict(_name = 'destination_host', requires = IS_IN_DB(db, 'host.id')))),
                      TR('', INPUT(_type='submit', _value = 'Migrate'))))

        form.vars.vm_name = db(db.vm_data.id == vm_id).select(db.vm_data.vm_name).first()['vm_name']  
        form.vars.current_host = db(db.host.id == host_id).select(db.host.host_ip).first()['host_ip']

        if is_vm_running(vm_id):
            add_live_migration_option(form)

    else:
        session.flash = "No host available right now"
        
    return form

# Check if vm is running
def is_vm_running(vmid):
    vm_status = db(db.vm_data.id == vmid).select().first()['status']
    if vm_status == VM_STATUS_RUNNING:
        return True
    else:
        return False


def vm_has_snapshots(vm_id):
    if (db(db.snapshot.vm_id == vm_id).select()):
        return True
    else:
        return False

def get_vm_util_data(util_period):
    vms = db(db.vm_data.status.belongs(VM_STATUS_RUNNING, VM_STATUS_SUSPENDED, VM_STATUS_SHUTDOWN)).select()
    vmlist = []
    for vm in vms:
        util_result = fetch_rrd_data(vm.vm_identity, util_period)
        element = {'vm_id' : vm.id,
                   'vm_name' : vm.vm_name,
                   'memory' : round(util_result[0]/(vm.RAM * MEGABYTE), 2),
                   'cpu' : round(util_result[1], 2),
                   'diskr' : round(util_result[2], 2),
                   'diskw' : round(util_result[3], 2),
                   'nwr' : round(util_result[4], 2),
                   'nww' : round(util_result[5], 2)}
        vmlist.append(element)
    return vmlist

def check_vm_resource(request_id):
    
    req_data = db.request_queue[request_id]
    security_domain_id = req_data.security_domain
    
    vlans = db(db.security_domain.id == security_domain_id)._select(db.security_domain.vlan)
    avl_ip = db((db.private_ip_pool.vm_id == None) & (db.private_ip_pool.vlan.belongs(vlans))).count()
    
    message = None
    if req_data.request_type == TASK_TYPE_CREATE_VM:
        if avl_ip == 0:
            message = "No private IPs available for security domain '%s" % req_data.security_domain.name
        if req_data.public_ip:
            
            if db(db.public_ip_pool.vm_id == None).count() == 0:
                message = "" if message == None else message + ", "
                message += "No public IP available"
            
    elif req_data.request_type == TASK_TYPE_CLONE_VM:
        if avl_ip < req_data.clone_count:
            message = "%s private IP(s) available for security domain '%s" % (str(avl_ip), req_data.security_domain.name)

    return message if message != None else 'Success'

def get_launch_vm_image_form():
    
    form_fields = ['vm_name','RAM','vCPU','template_id', 'datastore_id', 'vm_identity', 'purpose', 'security_domain', 'private_ip', 'public_ip']
    form_labels = {'vm_name':'VM Name', 'vm_identity':'VM Image Name'}

    db.vm_data.RAM.requires = IS_IN_SET(VM_RAM_SET, zero=None)
    db.vm_data.vCPU.requires = IS_IN_SET(VM_vCPU_SET, zero=None)
    db.vm_data.status.default = VM_STATUS_UNKNOWN
    db.vm_data.security_domain.notnull = True
    db.vm_data.template_id.notnull = True
    db.vm_data.extra_HDD.default = 0

    mark_required(db.vm_data)
    form =SQLFORM(db.vm_data, fields = form_fields, labels = form_labels, hidden=dict(vm_users='|', extra_disks='|'))
    
    add_extra_disk(form)
    add_requester_user(form)
    add_owner_user(form)
    add_collaborators(form)

    return form

def launch_vm_image_validation(form):
    
    requester_name = request.post_vars.requester_user    
    requester_info = get_user_info(requester_name)

    if requester_info != None:
        form.vars.requester_id = requester_info[0]
    else:
        form.errors.requester_user='Requester Username is not valid'
    
    owner_name = request.post_vars.owner_user    
    owner_info = get_user_info(owner_name)

    if owner_info != None:
        form.vars.owner_id = owner_info[0]
    else:
        form.errors.owner_user='Owner Username is not valid'
    
    
    #Verify if qcow2 image is present
    (vm_image_name, image_present) = get_vm_image_location(form.vars.datastore_id, form.vars.vm_identity)
    if not image_present:
        form.errors.vm_identity = vm_image_name + ' not found'
    
    if form.vars.private_ip.strip() != '':
        #Verify if public IP is available
        if is_valid_ipv4(form.vars.private_ip):
            # Verify if IP valid in given security domain
            security_domain = db.security_domain[form.vars.security_domain]
            sd_ip_range = security_domain.vlan.vlan_addr
            vlan_ip_prefix = sd_ip_range[:sd_ip_range.rindex('.')+1]
            
            if not form.vars.private_ip.startswith(vlan_ip_prefix):
                form.errors.private_ip = 'Private IP is not valid for given security domain'
            else:
                # Check if IP is already assigned
                private_ip_info = db.private_ip_pool(private_ip = form.vars.private_ip)
                if private_ip_info:
                    if private_ip_info.vm_id != None:
                        form.errors.private_ip = 'Private IP is not available'

        else:
            form.errors.private_ip = 'Private IP is not valid'
    else:
        form.vars.private_ip = None

    if form.vars.public_ip != PUBLIC_IP_NOT_ASSIGNED:
        #Check if Valid IP
        if is_valid_ipv4(form.vars.public_ip):
            public_ip_info = db.public_ip_pool(public_ip = form.vars.public_ip)
            if public_ip_info:
                if public_ip_info.vm_id != None:
                    form.errors.public_ip = 'Public IP is not available'
            else:
                form.errors.public_ip = 'Public IP is not configured'
        elif form.vars.public_ip == '':
            form.vars.public_ip = None
        else:
            form.errors.public_ip = 'Public IP is not valid'

    if not form.errors:
        vm_users = request.post_vars.vm_users
        user_list = []
        if vm_users and len(vm_users) > 1:
            for vm_user in vm_users[1:-1].split('|'):
                user_list.append(db(db.user.username == vm_user).select(db.user.id).first()['id'])
        
        form.vars.collaborators = user_list
    
        template_info = db.template[form.vars.template_id]
        form.vars.HDD = template_info.hdd
        
        extra_disks = request.post_vars.extra_disks
        disk_list = []
        if extra_disks and len(extra_disks) > 1:
            for extra_disk in extra_disks[1:-1].split('|'):
                disk_list.append(extra_disk)
        
        form.vars.extra_disk_list = disk_list

def check_vm_extra_disk(vm_image_name, disk_name, datastore_id):
    
    (disk_path, image_present, disk_size) = get_extra_disk_location(datastore_id, vm_image_name, disk_name, True)
    disk_info = "%s: %sG" %(disk_path, str(disk_size)) if image_present else None
    return disk_info

def exec_launch_vm_image(vm_id, vm_users, extra_disk_list):
    
    #Get VM details
    vm_details = db.vm_data[vm_id]
    #Make entry into user_vm_map
    add_vm_users(vm_id, vm_details.requester_id, vm_details.owner_id, vm_users)

    if vm_details.private_ip != None:
        private_ip_info = db.private_ip_pool(private_ip = vm_details.private_ip)
        if not private_ip_info:
            vlan_id = db.security_domain[vm_details.security_domain].vlan.id
            ip_pool_id = db.private_ip_pool.insert(private_ip=vm_details.private_ip, vlan=vlan_id)
            #Add DHCP entry for private IP
            add_private_ip(ip_pool_id)
    
    for extra_disk in extra_disk_list:

        db.attached_disks.insert(vm_id = vm_details.id,
                                 datastore_id = vm_details.datastore_id,
                                 capacity = 0,
                                 attached_disk_name=extra_disk)
#   Call Launch VM Image
    launch_existing_vm_image(vm_details)

