# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    import gluon
    global auth; auth = gluon.tools.Auth()
    from gluon import db, request, session
    from gluon import *  # @UnusedWildImport
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################

from applications.baadal.models.common_model import *
from applications.baadal.models.common_disk_model import update_attach_disk_request
from applications.baadal.models.common_vm_model import *
from applications.baadal.modules.helper import log_exception, logger
from applications.baadal.models.common_usercheck_model import *
from gluon import current


REQ_STATUS_REQUESTED = 1
REQ_STATUS_REJECTED  = 2
REQ_STATUS_VERIFIED  = 3
REQ_STATUS_APPROVED  = 4
REQ_STATUS_IN_QUEUE  = 5
REQ_STATUS_FAILED    =-1
ADMIN = 'admin'
ORGADMIN = 'orgadmin'
FACULTY = 'faculty'
USER = 'user'


#Update the dictionary with values specific to pending Edit Configuration request tab
def update_edit_config_request(vm_request, element):
    vm_data = db.vm_data[vm_request.parent_id]
    
    element['parent_vm_id'] = vm_request.parent_id
    element['old_RAM'] = str(round((vm_data.RAM/1024.0),2))+' GB'
    if vm_request.RAM == vm_data.RAM:
        element['RAM'] = 'Same'
    
    element['old_vCPUs'] = str(vm_data.vCPU) +' CPU'
    if vm_request.vCPU == vm_data.vCPU:
        element['vCPUs'] = 'Same'

    element['old_public_ip'] = (vm_data.public_ip != PUBLIC_IP_NOT_ASSIGNED)
    element['public_ip'] = vm_request.public_ip

    element['old_security_domain'] = vm_data.security_domain.name if vm_data.security_domain != None else '-';
    if vm_request.security_domain == vm_data.security_domain: element['security_domain'] = 'Same'
    else: element['security_domain'] = vm_request.security_domain.name if vm_request.security_domain != None else None;


def get_pending_request_query(statusList):
    db=current.db
    if is_moderator():
        _query = db(db.request_queue.status.belongs(statusList))
    elif is_orgadmin():
        users_of_same_org = db(auth.user.organisation_id == db.user.organisation_id)._select(db.user.id)
        _query = db((db.request_queue.status.belongs(statusList)) & (db.request_queue.requester_id.belongs(users_of_same_org)))
    else:
        _query = db((db.request_queue.status.belongs(statusList)) & (db.request_queue.owner_id == auth.user.id))
        
    return _query


def get_pending_approval_count():
    
    _query = get_pending_request_query([REQ_STATUS_VERIFIED])
    return _query.count()

def get_all_pending_req_count():

    _query = get_pending_request_query([REQ_STATUS_REQUESTED, REQ_STATUS_VERIFIED, REQ_STATUS_APPROVED])
    return _query.count()

#Creates dictionary of pending requests for differnt request types.
#It is used for HTML rendering
def get_pending_request_list(vm_requests):

    request_list = []
    for vm_request in vm_requests:
        
        element = {'id' : vm_request.id,
                   'vm_name' : vm_request.vm_name, 
                   'faculty_name' : vm_request.owner_id.first_name + ' ' + vm_request.owner_id.last_name, 
                   'requester_id' : vm_request.requester_id, 
                   'owner_id' : vm_request.owner_id,
                   'requester_name' : vm_request.requester_id.first_name + ' ' + vm_request.requester_id.last_name,
                   'org_id' : vm_request.requester_id.organisation_id,
                   'organisation' : vm_request.requester_id.organisation_id.name,
                   'vCPUs' : str(vm_request.vCPU)+' CPU', 
                   'RAM' : str(round((vm_request.RAM/1024.0),2)) + ' GB' if vm_request.RAM else None, 
                   'HDD' : str(vm_request.HDD) + ' GB' if vm_request.HDD else None,
                   'request_type' : vm_request.request_type,
                   'status' : vm_request.status}
        
        if vm_request.request_type == TASK_TYPE_CREATE_VM:
            update_install_vm_request(vm_request, element)
        elif vm_request.request_type == TASK_TYPE_CLONE_VM:
            update_clone_vm_request(vm_request, element)
        elif vm_request.request_type == TASK_TYPE_ATTACH_DISK:
            update_attach_disk_request(vm_request, element)
        elif vm_request.request_type == TASK_TYPE_EDITCONFIG_VM:
            update_edit_config_request(vm_request, element)
        
        request_list.append(element)
    return request_list


def get_request_info(request_id):
    return current.db.request_queue[request_id]


def get_request_status(iStatus):
    req_status_map = {
            REQ_STATUS_REQUESTED   :    'Requested',
            REQ_STATUS_REJECTED    :    'Rejected',
            REQ_STATUS_VERIFIED    :    'Verified',
            REQ_STATUS_APPROVED    :    'Approved',
            REQ_STATUS_IN_QUEUE    :    'In-Queue',
        }
    return req_status_map[iStatus]


def get_segregated_requests(request_list):
    
    install_requests = []
    clone_requests = []
    disk_requests = []
    edit_requests = []
    for req in request_list:
        if req['request_type'] == TASK_TYPE_CREATE_VM:
            install_requests.append(req)
        elif req['request_type'] == TASK_TYPE_CLONE_VM:
            clone_requests.append(req)
        elif req['request_type'] == TASK_TYPE_ATTACH_DISK:
            disk_requests.append(req)
        elif req['request_type'] == TASK_TYPE_EDITCONFIG_VM:
            edit_requests.append(req)
    return (install_requests, clone_requests, disk_requests, edit_requests)



