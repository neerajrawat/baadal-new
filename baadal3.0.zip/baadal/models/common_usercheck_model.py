from gluon import current

ADMIN = 'admin'
ORGADMIN = 'orgadmin'
FACULTY = 'faculty'
USER = 'user'


def is_moderator():
    return (ADMIN in current.auth.user_groups.values())

def is_faculty():
    return (FACULTY in current.auth.user_groups.values())

def is_orgadmin():
    return (ORGADMIN in current.auth.user_groups.values())

