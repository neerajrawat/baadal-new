# -*- coding: utf-8 -*-
###################################################################################
# Added to enable code completion in IDE's.
if 0:
    from gluon import *  # @UnusedWildImport
    from gluon import db,auth,request
    import gluon
    global auth; auth = gluon.tools.Auth()
    from applications.baadal.models import *  # @UnusedWildImport
###################################################################################
from applications.baadal.modules.auth_user import fetch_ldap_user, create_or_update_user, AUTH_TYPE_LDAP
from applications.baadal.modules.log_handler import logger
from applications.baadal.modules.helper import log_exception, get_datetime
from applications.baadal.modules.nat_mapper import create_vnc_mapping_in_nat, VNC_ACCESS_STATUS_ACTIVE
from datetime import timedelta
from applications.baadal.models.common_model import *
from applications.baadal.models.user_request_model import get_request_status
from applications.baadal.models.mail_handler import  send_email_vnc_access_granted


ADMIN = 'admin'
ORGADMIN = 'orgadmin'
FACULTY = 'faculty'
USER = 'user'


def add_user_verify_row(form, field_name, field_label, verify_function, verify_label = 'Verify', row_id='user_row', is_required=False):

    _input=INPUT(_name=field_name, _id=field_name) # create INPUT
    _link = TD(A(verify_label, _href='#',_onclick=verify_function))
    _label = LABEL(SPAN(field_label, ': ', SPAN('*', _class='fld_required'), ' ')) if is_required else LABEL(SPAN(field_label, ': '))

    field_elem = TR(_label, _input, _link, _id=row_id)
    form[0].insert(-1, field_elem)#insert tr element in the form


def get_user_info(username, roles=[USER, FACULTY, ORGADMIN, ADMIN]):

    user_query = db((db.user.username == username) 
             & (db.user.id == db.user_membership.user_id)
             & (db.user_membership.group_id == db.user_group.id)
             & (db.user_group.role.belongs(roles)))
    
    user = user_query.select(db.user.ALL).first()
    
    # If user not present in DB
    if not user:
        if current.auth_type == AUTH_TYPE_LDAP :
            user_info = fetch_ldap_user(username)
            if user_info:
                if [obj for obj in roles if obj in user_info['roles']]:
                    create_or_update_user(user_info, False)
                    user = user_query.select(db.user.ALL).first()
    
    if user:
        if is_moderator() | (user['organisation_id'] == auth.user.organisation_id):
            return (user['id'], (user['first_name'] + ' ' + user['last_name']))


def get_attach_extra_disk_form(vm_id):

    vm_data = db.vm_data[vm_id]
    
    db.request_queue.parent_id.default = vm_data.id
    db.request_queue.vm_name.default = vm_data.vm_name
    db.request_queue.RAM.default = vm_data.RAM
    db.request_queue.vCPU.default = vm_data.vCPU
    db.request_queue.HDD.default = vm_data.HDD
    db.request_queue.extra_HDD.default = vm_data.extra_HDD
    db.request_queue.request_type.default = TASK_TYPE_ATTACH_DISK
    db.request_queue.status.default = get_request_status()
    db.request_queue.requester_id.default = auth.user.id
    db.request_queue.owner_id.default = vm_data.owner_id
    db.request_queue.attach_disk.requires = IS_INT_IN_RANGE(1,101)
    db.request_queue.vm_name.writable = False
    db.request_queue.HDD.writable = False
    db.request_queue.extra_HDD.writable = False

    form_fields = ['vm_name', 'HDD', 'extra_HDD', 'attach_disk', 'purpose']
    
    form =SQLFORM(db.request_queue, fields = form_fields)
    return form    


def grant_vnc_access(vm_id):
    active_vnc = db((db.vnc_access.vm_id == vm_id) & (db.vnc_access.status == VNC_ACCESS_STATUS_ACTIVE)).count()
    if active_vnc > 0:
        msg = 'VNC access already granted. Please check your mail for further details.'
    else:
        vnc_count = db((db.vnc_access.vm_id == vm_id) & (db.vnc_access.time_requested > (get_datetime() - timedelta(days=1)))).count()
        if vnc_count >= MAX_VNC_ALLOWED_IN_A_DAY :
            msg = 'VNC request has exceeded limit.'
        else:
            try:
                create_vnc_mapping_in_nat(vm_id)
                
                vnc_info = db((db.vnc_access.vm_id == vm_id) & (db.vnc_access.status == VNC_ACCESS_STATUS_ACTIVE)).select()
                if vnc_info:
                    vm_users = []
                    for user in db(db.user_vm_map.vm_id == vm_id).select(db.user_vm_map.user_id):
                        vm_users.append(user['user_id'])
    
                    send_email_vnc_access_granted(vm_users, 
                                                  vnc_info[0].vnc_server_ip, 
                                                  vnc_info[0].vnc_source_port, 
                                                  vnc_info[0].vm_id.vm_name, 
                                                  vnc_info[0].time_requested)
                else: 
                    raise
                msg = 'VNC access granted. Please check your mail for further details.'
            except:
                msg = 'Some Error Occurred. Please try later'
                log_exception()
                pass
    return msg


